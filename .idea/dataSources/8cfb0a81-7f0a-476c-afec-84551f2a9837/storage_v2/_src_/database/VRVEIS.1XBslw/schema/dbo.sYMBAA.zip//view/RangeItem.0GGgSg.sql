
CREATE VIEW dbo.RangeItem
AS
SELECT dbo.RangeSet.LineStyle, dbo.RangeSet.LineCorR, dbo.RangeSet.LineWidth, 
      dbo.RangeSet.LineCorG, dbo.RangeSet.LineCorB, dbo.RangeSet.StockCorR, 
      dbo.RangeSet.StockCorG, dbo.RangeSet.StockCorB, dbo.RangeSet.RectL, 
      dbo.RangeSet.RectT, dbo.RangeSet.RectR, dbo.RangeSet.RectB, 
      dbo.RangeSet.IfStock, dbo.RangeSet.ERstyle, dbo.NormalSet.ContrlID, 
      dbo.NormalSet.ContrlStyle, dbo.NormalSet.PicIndex, dbo.NormalSet.PreContrlID
FROM dbo.RangeSet INNER JOIN
      dbo.NormalSet ON dbo.RangeSet.ContrlID = dbo.NormalSet.ContrlID
GO

