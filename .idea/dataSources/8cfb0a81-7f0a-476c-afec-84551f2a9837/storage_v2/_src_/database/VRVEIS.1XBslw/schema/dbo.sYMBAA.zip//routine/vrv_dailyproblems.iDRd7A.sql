CREATE PROCEDURE [dbo].[vrv_dailyproblems] AS
declare @strTime varchar(20)
declare @strSubTime varchar(20)
declare @strTimeA varchar(20)
declare @strTimeB varchar(20)
declare @strTimec varchar(20)
declare @strFlag varchar(20)
select   @strTime = Dateadd(Dd, - 1, getdate())
select   @strSubTime = cast(datepart(Mm, @strTime) AS varchar(2)) + '/' + cast(datepart(Dd, @strTime) AS varchar(2))
select   @strTimeA = datename(Yy, @strTime) + '-' + datename(Mm, @strTime) + '-' + datename(Dd, @strTime) + ' ' + '0:00:00'
select   @strTimeB = datename(Yy, @strTime) + '-' + datename(Mm, @strTime) + '-' + datename(Dd, @strTime) + ' ' + '23:59:59'
select   @strFlag = '30problems'

/*统计每天报告问题的计算机数*/

delete from PastStatus where execTime=@strTimeA  and CfgFlag=@strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgValue3,Cfgvalue4,CfgFlag) 
select @strSubTime, @strTimeA, CountVirus, CountPatch, CountErr, CountPolicy,  @strFlag from 
(SELECT COUNT(DISTINCT Virus.DeviceID) AS CountVirus FROM Virus inner join device on virus.deviceid = device.deviceid
where (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between  @strTimeA and @strTimeB) as t1 
left join (select COUNT(DeviceID) AS CountPatch FROM  Device WHERE (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) and 
(CountPatchLevel3 <> 0) OR(CountPatchLevel4 <> 0)) as t2 on 1=1 
left join (SELECT     COUNT(DISTINCT ErrorMessage.DeviceID) AS CountErr FROM ErrorMessage inner join device on ErrorMessage.deviceid = device.deviceid where (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) and  ErrorTime between @strTimeA and @strTimeB) as t3 on 1=1
left join (SELECT     COUNT(DISTINCT Policy_Exec.DeviceID) AS CountPolicy  FROM Policy_Exec  inner join device on   Policy_Exec.deviceid = device.deviceid WHERE    (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) and (ISNULL(CurrentDate,'') <> ISNULL(AgentDate, ''))) AS t4 ON 1 = 1

/*统计每天恶意软件问题的计算机数*/

select              @strFlag = '30virus'
delete from PastStatus where execTime= @strTimeA and CfgFlag=@strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgValue3,CfgValue4,CfgValue5,CfgValue6,CfgFlag) 
select @strSubTime, @strTimeA,cnt1,cnt2,cnt3,cnt4,cnt5,cnt6, @strFlag from (SELECT COUNT(DeviceID) AS cnt1  FROM  (SELECT Virus.DeviceID FROM Virus  INNER JOIN Device ON Device.DeviceID = Virus.DeviceID  WHERE  (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between @strTimeA and @strTimeB AND (KillResult = 'KILLED') GROUP BY Virus.DeviceID, VirusName) as d1) AS t1 
LEFT JOIN (SELECT COUNT(DeviceID) AS cnt2 FROM (SELECT Virus.DeviceID FROM Virus  INNER JOIN Device ON Device.DeviceID = Virus.DeviceID  WHERE  (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between @strTimeA and  @strTimeB AND (KillResult = 'KILL_FAIL') GROUP BY Virus.DeviceID, VirusName) as d2) AS t2 ON 1 = 1 
LEFT JOIN (SELECT COUNT(DeviceID) AS cnt3 FROM ( SELECT Virus.DeviceID FROM Virus  INNER JOIN Device ON Device.DeviceID = Virus.DeviceID  WHERE  (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between @strTimeA and @strTimeB AND (KillResult = 'DELETED' ) GROUP BY Virus. DeviceID, VirusName) as d3) AS t3 ON 1 = 1  
LEFT JOIN (SELECT COUNT(DeviceID) AS cnt4 FROM (SELECT Virus.DeviceID FROM Virus  INNER JOIN Device ON Device.DeviceID = Virus.DeviceID  WHERE  (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between @strTimeA and @strTimeB AND (KillResult = 'DELETE_FAIL') GROUP BY Virus.DeviceID, VirusName) as d4) AS t4 ON 1 = 1 
LEFT JOIN (SELECT COUNT(DeviceID) AS cnt5 FROM (SELECT Virus.DeviceID FROM Virus  INNER JOIN Device ON Device.DeviceID = Virus.DeviceID  WHERE  (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between @strTimeA and @strTimeB AND (KillResult = 'KILLRESULT_DEL_DELAY') GROUP BY Virus.DeviceID, VirusName) as d5) AS t5 ON 1 = 1 
LEFT JOIN (SELECT COUNT(DeviceID) AS cnt6 FROM (SELECT Virus.DeviceID FROM Virus  INNER JOIN Device ON Device.DeviceID = Virus.DeviceID  WHERE  (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND VirusTime between @strTimeA and @strTimeB AND (KillResult = 'IGNORE') GROUP BY Virus.DeviceID, VirusName) as d6) AS t6 ON 1 = 1

/*统计每天策略部署问题的计算机数*/

select              @strFlag = '30policy'
delete from PastStatus where execTime= @strTimeA and CfgFlag= @strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgValue3,CfgFlag) 
select @strSubTime, @strTimeA,cnt1,cnt2,cnt3-cnt1-cnt2,@strFlag from (SELECT     COUNT(DISTINCT Policy_Exec.DeviceID) AS cnt1
FROM         Policy_Exec INNER JOIN
                      Device ON Policy_Exec.DeviceID = Device.DeviceID
WHERE     (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (Policy_Exec.CurrentDate = Policy_Exec.AgentDate) AND 
                      (Policy_Exec.DeviceID NOT IN
                          (SELECT DISTINCT Policy_Exec_1.DeviceID
                            FROM          Policy_Exec AS Policy_Exec_1 INNER JOIN
                                                   Device AS Device_1 ON Policy_Exec_1.DeviceID = Device_1.DeviceID
                            WHERE      (Device_1.Registered = 1) AND (DATEDIFF(Mi, Device_1.ReportTime, GETDATE()) <= 1440) AND 
                                                   (Policy_Exec_1.CurrentDate <> Policy_Exec_1.AgentDate)))
) AS t1 
LEFT OUTER JOIN 
     (SELECT     COUNT(DISTINCT Policy_Exec.DeviceID) AS cnt2
FROM         Policy_Exec INNER JOIN
                      Device ON Policy_Exec.DeviceID = Device.DeviceID
WHERE     (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (Policy_Exec.CurrentDate <> Policy_Exec.AgentDate)
) AS t2 ON 1 = 1 
LEFT OUTER JOIN  
        (SELECT COUNT(DeviceID) AS cnt3         FROM Device         WHERE (Registered = 1) AND (DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440)) 
      AS t3 ON 1 = 1

/*统计每天报警问题的计算机数*/

select              @strFlag = '30error'
delete from PastStatus where execTime= @strTimeA and CfgFlag= @strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgValue3,CfgValue4,CfgValue5,CfgFlag) 
select @strSubTime, @strTimeA,cnt1,cnt2,cnt3,cnt4,cnt5,@strFlag  from 
(SELECT     COUNT(ErrorMessage.ErrorID) AS cnt1
                       FROM          ErrorMessage INNER JOIN
                                              Device ON ErrorMessage.DeviceID = Device.DeviceID
                       WHERE   ErrorTime  between @strTimeA and @strTimeB AND (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (ErrorType = 0)) 
                      AS t1 LEFT OUTER JOIN
                          (SELECT     COUNT(ErrorMessage.ErrorID) AS cnt2
                            FROM          ErrorMessage INNER JOIN
                                                   Device ON ErrorMessage.DeviceID = Device.DeviceID
                            WHERE     ErrorTime  between @strTimeA and @strTimeB AND (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (ErrorType = 1)) 
                      AS t2 ON 1 = 1 LEFT OUTER JOIN
                          (SELECT     COUNT(ErrorMessage.ErrorID) AS cnt3
                            FROM          ErrorMessage INNER JOIN
                                                   Device  ON ErrorMessage.DeviceID = Device.DeviceID
                            WHERE   ErrorTime  between @strTimeA and @strTimeB  AND (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (ErrorType = 2))  AS t3 ON 1 = 1 
LEFT OUTER JOIN
                          (SELECT     COUNT(ErrorMessage.ErrorID) AS cnt4
                            FROM          ErrorMessage INNER JOIN
                                                   Device  ON ErrorMessage.DeviceID = Device.DeviceID
                            WHERE   ErrorTime  between @strTimeA and @strTimeB AND (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (ErrorType = 8))  AS t4 ON 1 = 1 
LEFT OUTER JOIN
                          (SELECT     COUNT(ErrorMessage.ErrorID) AS cnt5
                            FROM          ErrorMessage INNER JOIN
                                                   Device  ON ErrorMessage.DeviceID = Device.DeviceID
                            WHERE   ErrorTime  between @strTimeA and @strTimeB AND (Device.Registered = 1) AND (DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440) AND (ErrorType = 4))  AS t5 ON 1 = 1

/*统计每天安全的计算机数*/

select              @strFlag = '30security'
delete from PastStatus where execTime= @strTimeA and CfgFlag=@strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgFlag) 
select @strSubTime, @strTimeA,cnt1,(cnt2-cnt1) as cnt2, @strFlag from 
(SELECT COUNT(*) AS cnt1  FROM Device WHERE (Registered = 1) AND (DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440) AND 
              (CountPatchLevel3 = 0) AND (CountPatchLevel4 = 0) AND 
              Deviceid NOT IN
                  (SELECT DeviceID
                 FROM ErrorMessage
                 WHERE ErrorTime  between @strTimeA and @strTimeB
                 UNION
                 SELECT DeviceID
                 FROM Virus
                 WHERE  VirusTime  between @strTimeA and @strTimeB
                 UNION
                 SELECT DISTINCT DeviceID
                 FROM Policy_Exec
                 WHERE Isnull(CurrentDate, '') <> isnull(AgentDate,''))) AS t1 
LEFT JOIN  (SELECT count(deviceid) AS cnt2  FROM device  WHERE Registered = 1 AND DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440) AS t2 ON 1 = 1

/*统计每天安全状态评估的计算机数*/

SET              @strFlag = '30serious'
delete from PastStatus where execTime=@strTimeA and CfgFlag=@strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgValue3,CfgFlag) 
select @strSubTime, @strTimeA,cnt1,cnt2,cnt3, @strFlag from 
(SELECT COUNT(DeviceID) AS cnt1
         FROM Device 
         WHERE (Registered = 1) AND (DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440) AND 
               (CountPatchLevel3 + CountPatchLevel4 = 0) AND (DeviceID NOT IN
                   (SELECT DISTINCT DeviceID
                  FROM Policy_Exec
                  WHERE (ISNULL(CurrentDate, '') <> ISNULL(AgentDate, '')))) AND 
               (RunLevel = 4)) AS t1 LEFT OUTER JOIN
          (SELECT COUNT(DeviceID) AS cnt2
         FROM Device
         WHERE (Registered = 1) AND (DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440) AND 
               (CountPatchLevel3 + CountPatchLevel4 = 0) AND (DeviceID NOT IN
                   (SELECT DISTINCT DeviceID
                  FROM Policy_Exec
                  WHERE (ISNULL(CurrentDate, '') <> ISNULL(AgentDate, '')))) AND 
               (RunLevel < 4)) AS t2 ON 1 = 1 LEFT OUTER JOIN
          (SELECT COUNT(DeviceID) AS cnt3
         FROM Device
         WHERE (Registered = 1) AND (DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440) AND 
               (CountPatchLevel3 + CountPatchLevel4 > 0) OR
               (Registered = 1) AND (DATEDIFF(Mi, ReportTime, GETDATE()) <= 1440) AND 
               (DeviceID IN
                   (SELECT DISTINCT DeviceID
                  FROM Policy_Exec
                  WHERE (ISNULL(CurrentDate, '') <> ISNULL(AgentDate, ''))))) AS t3 ON  1 = 1
GO

