
CREATE VIEW dbo.RoomItem
AS
SELECT dbo.NormalSet.ContrlStyle, dbo.NormalSet.PreContrlID, dbo.NormalSet.PicIndex, 
      dbo.IPRonge.Pwd, dbo.IPRonge.Sip1, dbo.IPRonge.Eip1, dbo.IPRonge.Sip2, 
      dbo.IPRonge.Eip2, dbo.IPRonge.Sip3, dbo.IPRonge.Eip3, dbo.IPRonge.Sip4, 
      dbo.IPRonge.Eip4, dbo.IPRonge.Sip5, dbo.IPRonge.Eip5, dbo.IPRonge.Sip6, 
      dbo.IPRonge.Sip7, dbo.IPRonge.Eip7, dbo.IPRonge.Sip8, dbo.IPRonge.Eip8, 
      dbo.IPRonge.Sip9, dbo.IPRonge.Eip6, dbo.IPRonge.Eip9, dbo.IPRonge.Sip10, 
      dbo.IPRonge.Eip10, dbo.SRitemSet.ShowName, dbo.SRitemSet.ShowCorR, 
      dbo.SRitemSet.ShowCorG, dbo.SRitemSet.ShowCorB, dbo.SRitemSet.ManagerMan, 
      dbo.SRitemSet.ManagerTel, dbo.SRitemSet.ManagerEmail, 
      dbo.SRitemSet.DeptName, dbo.SRitemSet.LoadNetStyle, dbo.SRitemSet.Scale, 
      dbo.SRitemSet.PointID, dbo.SRitemSet.PicPath, dbo.SRitemSet.PicID, 
      dbo.SRitemSet.RectL, dbo.SRitemSet.RectT, dbo.SRitemSet.RectR, 
      dbo.SRitemSet.RectB, dbo.NormalSet.ContrlID
FROM dbo.IPRonge INNER JOIN
      dbo.NormalSet ON dbo.IPRonge.ContrlID = dbo.NormalSet.ContrlID INNER JOIN
      dbo.SRitemSet ON dbo.IPRonge.ContrlID = dbo.SRitemSet.ContrlID AND 
      dbo.NormalSet.ContrlID = dbo.SRitemSet.ContrlID
GO

