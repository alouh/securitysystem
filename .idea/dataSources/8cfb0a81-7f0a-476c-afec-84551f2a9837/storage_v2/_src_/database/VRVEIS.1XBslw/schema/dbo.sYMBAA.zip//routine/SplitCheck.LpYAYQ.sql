create function [SplitCheck](@FileName as varchar(500))
returns varchar(500) as
begin
    declare @SplitString varchar(100),@split varchar(50) 
	Select @SplitString=CfgValue from Vrveisconfig Where CfgName='SplitCheckValue' --'.cn;.com;.net'
    set @split = ';'
     DECLARE @CurrentIndex int;
     DECLARE @NextIndex int;
     DECLARE @ReturnText nvarchar(1000);
     SELECT @CurrentIndex=1;
    WHILE(@CurrentIndex<=len(@SplitString))
         BEGIN
             SELECT @NextIndex=charindex(@split,@SplitString,@CurrentIndex);
             IF(@NextIndex=0 OR @NextIndex IS NULL)
                 SELECT @NextIndex=len(@SplitString)+1;
                 SELECT @ReturnText=substring(@SplitString,@CurrentIndex,@NextIndex-@CurrentIndex);
                 if exists(select 1 where @FileName like '%'+@ReturnText+'%')
                 return dbo.GetFileExtension(@FileName)
                 SELECT @CurrentIndex=@NextIndex+1;
            END
    return @FileName
end
GO

