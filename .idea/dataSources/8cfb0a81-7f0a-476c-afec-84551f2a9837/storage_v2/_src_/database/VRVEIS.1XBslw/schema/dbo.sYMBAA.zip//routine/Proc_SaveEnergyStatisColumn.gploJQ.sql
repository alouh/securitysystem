CREATE PROCEDURE [dbo].[Proc_SaveEnergyStatisColumn]
(
	@beginDateTime VARCHAR(50),
	@endDateTime	VARCHAR(50),
	@tableRand		VARCHAR(50),						--用于构造临时表
	@classIds	VARCHAR(2000),							--区域ClassId
	@groupIds	VARCHAR(2000)
)
AS
BEGIN
	DECLARE	@deviceId				VARCHAR(100),				
			@deviceType				VARCHAR(100),				--设备类型
			@deptName				VARCHAR(64),			--部门名称
			@monitor_Note			INT,					--笔记本显示器节能
			@suspend_Note			INT,					--笔记本待机节能
			@sleep_Note				INT,					--笔记本休眠节能
			@shutDown_Note			INT,					--笔记本关机节能
			@monitor_Desk			INT,					--台式机显示器节能
			@suspend_Desk			INT,					--台式机待机节能
			@sleep_Desk				INT,					--台式机休眠节能
			@shutDown_Desk			INT,					--台式机关机节能
			@deviceIdcondition		VARCHAR(1000),			--搜索DeviceId范围组合的查询条件
			@searchConditon			VARCHAR(1000),			-- 搜索条件，比如单位、部门
			@sum					INT,					--节能时间
			@count					INT,					--节能
			@tempTable	  VARCHAR(100),						--临时表名
			@sql					NVARCHAR(2000)
	SELECT @monitor_Note=[RunPower]
		  ,@suspend_Note=[StandbyPower]
		  ,@sleep_Note=[SleepPower]
		  ,@shutDown_Note=[DisplayPower]
		FROM PowerConfiguration
		WHERE WID=0
	SELECT @monitor_Desk=[RunPower]
		  ,@suspend_Desk=[StandbyPower]
		  ,@sleep_Desk=[SleepPower]
		  ,@shutDown_Desk=[DisplayPower]
		FROM PowerConfiguration
		WHERE WID=1
	IF (LEN(@classIds)=0)
		SET @classIds=-1		
	IF (@classIds='-1')
		SET @deviceIdcondition='SELECT deviceId FROM Device d WHERE 1=1';
	IF (@classIds<>'-1')
		BEGIN				
			SET @deviceIdcondition='SELECT deviceId FROM Device d INNER JOIN class c ON d.classId=c.classId AND c.classId  in('+@classIds+')'
			IF (@groupIds<>'0')
				SET @deviceIdcondition=@deviceIdcondition+ 'UNION SELECT deviceId FROM dbo.Device d WHERE d.DeviceID IN (SELECT DeviceID FROM DistributeTemp WHERE TypeID in('+@groupIds+'))'
	END	
	SET @searchConditon='	AND	1=1	'
	IF LEN(@beginDateTime)>0
		SET @searchConditon=@searchConditon+'	AND	ClientTime >='''+@beginDateTime+''''
	IF LEN(@endDateTime)>0
		SET @searchConditon=@searchConditon+'	AND	ClientTime <='''+@endDateTime+''''
	SET @tempTable='temp'+@tableRand
	SET @sql='CREATE TABLE '+@tempTable+
		'(  DeptName VARCHAR(80) NULL,
			Total		INT NOT NULL			
		)'
		PRINT @sql
		EXEC (@sql)	
	DECLARE cur CURSOR FOR SELECT B.DeviceId,B.DeptName, A.ExField3 AS DeviceType FROM dbo.EnergyAuditEvent A INNER JOIN Device B ON A.DeviceId=B.DeviceId
	OPEN cur
	FETCH cur INTO @deviceId,@deptName,@deviceType
	WHILE(@@FETCH_STATUS=0)
		BEGIN			
				/*--初始 节能数为0--*/
				SET @count=0
				/*--统计显示器节能--*/
				SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent	WHERE ActionType =10005 AND DeviceId IN ('+@deviceIdcondition+') AND DeviceId='+@deviceId+''+@searchConditon
				PRINT '统计显示器节能sql'
				PRINT @sql
				EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
				IF @sum IS NULL
					SET @sum=0
				/*--如果是台式机--*/
				IF (@deviceType=3)
					SET @count=@count+@sum*@monitor_Desk
				ELSE IF (@deviceType=10)
					SET @count=@count+@sum*@monitor_Note
				/*--统计待机节能--*/
				SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent	WHERE ActionType =10007 AND DeviceId IN ('+@deviceIdcondition+') AND DeviceId='+@deviceId+''+@searchConditon
				EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
				PRINT '统计待机节能sql'
				PRINT @sql
				IF @sum IS NULL
					SET @sum=0
				/*--如果是台式机--*/
				IF (@deviceType=3)
					SET @count=@count+@sum*@suspend_Desk
				ELSE IF (@deviceType=10)
					SET @count=@count+@sum*@suspend_Note
				/*--统计休眠节能--*/
				SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent	WHERE ActionType =10009 AND DeviceId IN ('+@deviceIdcondition+') AND DeviceId='+@deviceId+''+@searchConditon
				EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
				PRINT '统计休眠节能sql'
				PRINT @sql
				IF @sum IS NULL
					SET @sum=0
				/*--如果是台式机--*/
				IF (@deviceType=3)
					SET @count=@count+@sum*@sleep_Desk
				ELSE IF (@deviceType=10)
					SET @count=@count+@sum*@sleep_Note
				/*--统计关机节能--*/
				SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent	WHERE ActionType =10011 AND DeviceId IN ('+@deviceIdcondition+') AND DeviceId='+@deviceId+''+@searchConditon
				EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
				PRINT '统计关机节能sql'
				PRINT @sql
				IF @sum IS NULL
					SET @sum=0
				/*--如果是台式机--*/
				IF (@deviceType=3)
					SET @count=@count+@sum*@shutDown_Desk
				ELSE IF (@deviceType=10)
					SET @count=@count+@sum*@shutDown_Note
				SET @sql='INSERT INTO '+@tempTable+'(DeptName,Total)VALUES('''+@deptName+''','+CAST(@count AS VARCHAR(200))+')'
				EXEC (@sql)
			FETCH cur INTO @deviceId,@deptName,@deviceType
		END
	CLOSE cur
	DEALLOCATE cur
	SET @sql='SELECT  * FROM '+@tempTable
	PRINT @sql
	EXEC (@sql)
	EXEC ('DROP TABLE '+@tempTable)  
END
GO

