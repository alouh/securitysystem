
CREATE VIEW dbo.V_AuditList
AS
SELECT dbo.V_AuditEvent.PEventID, dbo.V_AuditEvent.ExtNum, 
      dbo.V_AuditEvent.PolicyName, dbo.V_AuditEvent.Description, 
      dbo.V_AuditEvent.Version, dbo.V_AuditEvent.Disabled, dbo.V_AuditEvent.UpTime, 
      dbo.V_AuditEvent.ClientTime, dbo.V_AuditEvent.AuthUserName, 
      dbo.V_AuditEvent.LookFlag, dbo.V_AuditEvent.Reserved1, 
      dbo.V_AuditEvent.Reserved2, dbo.V_AuditEvent.TableName, 
      dbo.V_AuditEvent.PolicyID, dbo.Device.DeviceID, dbo.Device.DeptName, 
      dbo.Device.OfficeName, dbo.Device.FloorNumber, dbo.Device.RoomNumber, 
      dbo.Device.UserName, dbo.Device.IPAddres, dbo.Device.NumIPAddress, 
      dbo.Device.Tel, dbo.Device.Email, dbo.V_AuditEvent.IPAddress AS IPAddress1, 
      dbo.V_AuditEvent.ClassName, dbo.Device.ClassID, dbo.Device.DeviceCode, 
      dbo.Device.DevOnlyID, dbo.Device.DeviceName
FROM dbo.V_AuditEvent INNER JOIN
      dbo.Device ON dbo.V_AuditEvent.OnlyID = dbo.Device.DeviceID
GO

