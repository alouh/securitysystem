
CREATE VIEW dbo.View_scanwarning
AS
SELECT dbo.MapRegionScan.ScanID, dbo.MapRegionScan.RegID, 
      dbo.MapRegion.OrganCode, dbo.MapRegion.OrganName, dbo.MapRegion.RegName, 
      dbo.MapRegionScan.ScanName, dbo.MapRegionScan.IPAddress, 
      dbo.MapRegionScan.RunStatus, dbo.MapIPRange.RangeID, dbo.MapIPRange.StartIP, 
      dbo.MapIPRange.EndIP, dbo.MapIPRange.Flag
FROM dbo.MapRegionScan INNER JOIN
      dbo.MapRegion ON dbo.MapRegionScan.RegID = dbo.MapRegion.RegID INNER JOIN
      dbo.MapIPRange ON dbo.MapRegionScan.ScanID = dbo.MapIPRange.ScanID
GO

