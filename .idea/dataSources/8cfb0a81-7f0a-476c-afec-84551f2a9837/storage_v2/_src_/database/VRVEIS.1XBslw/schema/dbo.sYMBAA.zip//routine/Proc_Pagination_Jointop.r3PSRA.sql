/*通用分页存储过程　CAST(@pageSize as VARCHAR(4))　改成　CAST(@pageSize as VARCHAR(8))　*/
CREATE PROCEDURE [dbo].[Proc_Pagination_Jointop]  
(  
@tblName     nvarchar(4000),        ----要显示的表或多个表的连接  
@TableList     varchar(1000),        ----要替换的表或多个表的连接  
@fldName     nvarchar(4000) = '*',    ----要显示的字段列表  
@FieldList     varchar(1000) = '*',    ----要替换的字段列表  
@pageSize    int = 10,        ----每页显示的记录个数  
@page        int = 1,        ----要显示那一页的记录  
@fldSort    nvarchar(200) = null,    ----排序字段列表或条件  
@Sort        bit = 0,        ----排序方法，0为升序，1为降序(如果是多字段排列Sort指代最后一个排序字段的排列顺序(最后一个排序字段不加排序标记)--程序传参如：' SortA Asc,SortB Desc,SortC ')  
@strCondition    nvarchar(4000) = null,    ----查询条件,不需where  
@WhereList     varchar(1000) = '*',    ----要替换的查询条件  
@ID        nvarchar(150),        ----主表的主键  
@Dist                 bit = 0,           ----是否添加查询字段的 DISTINCT 默认0不添加/1添加  
@pageCount    int = 1 output,            ----查询结果分页后的总页数  
@Counts    int = 1 output                ----查询到的记录数  
)  
AS  
SET NOCOUNT ON  
Declare @sqlTmp nvarchar(4000)        ----存放动态生成的SQL语句  
Declare @strTmp nvarchar(4000)        ----存放取得查询结果总数的查询语句  
Declare @strID     nvarchar(4000)        ----存放取得查询开头或结尾ID的查询语句  
Declare @strSortType nvarchar(10)    ----数据排序规则A  
Declare @strFSortType nvarchar(10)    ----数据排序规则B  
Declare @SqlSelect nvarchar(50)         ----对含有DISTINCT的查询进行SQL构造  
Declare @SqlCounts nvarchar(50)          ----对含有DISTINCT的总数查询进行SQL构造  
declare @TempID nvarchar(50) -- 主键带表名，临时处理，去掉表名，改成临时表的别名+主键ID名  
if @Dist  = 0  
begin  
    set @SqlSelect = 'select '  
    set @SqlCounts = 'Count(*)'  
end  
else  
begin  
    set @SqlSelect = 'select distinct '  
    set @SqlCounts = 'Count(DISTINCT '+@ID+')'  
end  
if @Sort=0  
begin  
    set @strFSortType=' ASC '  
    set @strSortType=' DESC '  
end  
else  
begin  
    set @strFSortType=' DESC '  
    set @strSortType=' ASC '  
end  
 /*-----生成查询语句-----*/  
 /*-----此处@strTmp为取得查询结果数量的语句-----*/  
if @strCondition is null or @strCondition=''     --没有设置显示条件  
begin  
    set @sqlTmp =  @fldName + ' From ' + @tblName  
    set @strTmp = @SqlSelect+' @Counts='+@SqlCounts+' FROM '+@tblName  
    set @strID = ' From ' + @tblName  
end  
else  
begin  
    set @sqlTmp = + @fldName + 'From ' + @tblName + ' where (1=1) ' + @strCondition  
    set @strTmp = @SqlSelect+' @Counts='+@SqlCounts+' FROM '+@tblName + ' where (1=1) ' + @strCondition  
    set @strID = ' From ' + @tblName + ' where (1=1) ' + @strCondition  
end  
 /*-----取得查询结果总数量-----*/  
set @strTmp = replace(replace(replace(@strTmp,'[FieldList]',@FieldList),'[TableList]',@TableList),'[WhereList]',@WhereList)  
exec sp_executesql @strTmp,N'@Counts int out ',@Counts out  
declare @tmpCounts int  
if @Counts = 0  
    set @tmpCounts = 1      
else  
    set @tmpCounts = @Counts  
    /*-----取得分页总数-----*/  
    set @pageCount=(@tmpCounts+@pageSize-1)/@pageSize  
    /*-----当前页大于总页数 取最后一页-----*/  
    if @page>@pageCount  
        set @page=@pageCount  
    /*-----数据分页2分处理-----*/  
    declare @pageIndex int --总数/页大小  
    declare @lastcount int --总数%页大小   
    set @pageIndex = @tmpCounts/@pageSize  
    set @lastcount = @tmpCounts%@pageSize  
    if @lastcount > 0  
        set @pageIndex = @pageIndex + 1  
    else  
        set @lastcount = @pagesize  
    /*-----显示分页-----*/  
    if @strCondition is null or @strCondition=''     --没有设置显示条件  
    begin  
                if @page=1  
                    set @strTmp=@SqlSelect+' top '+ CAST(@pageSize as VARCHAR(8))+' '+ @fldName+' from '+@tblName                          
                        +' order by '+ @fldSort +' '+ @strFSortType  
                else  
                begin      
                    if charindex('.',@ID) > 0    
                        set @TempID = 'TBMinID' + substring(@ID,charindex('.',@ID),len(@ID))  
                    else  
                        set @TempID = @ID                  
                    set @strTmp=@SqlSelect+' top '+ CAST(@pageSize as VARCHAR(8))+' '+ @fldName+' from '+@tblName  
                        +' where '+@ID+' <(select min('+ @ID +') from ('+ @SqlSelect+' top '+ CAST(@pageSize*(@page-1) as Varchar(20)) +' '+ @ID +' from '+@tblName  
                        +' order by '+ @fldSort +' '+ @strFSortType+') AS TBMinID)'  
                        +' order by '+ @fldSort +' '+ @strFSortType  
                end   
    end  
    else --有查询条件  
    begin  
                if @page=1  
                    set @strTmp=@SqlSelect+' top '+ CAST(@pageSize as VARCHAR(8))+' '+ @fldName+' from '+@tblName                          
                        +' where 1=1 ' + @strCondition + ' order by '+ @fldSort +' '+ @strFSortType  
                else  
                begin      
                    if charindex('.',@ID) > 0    
                        set @TempID = 'TBMinID' + substring(@ID,charindex('.',@ID),len(@ID))  
                    else  
                        set @TempID = @ID  
                    set @strTmp=@SqlSelect+' top '+ CAST(@pageSize as VARCHAR(8))+' '+ @fldName+' from '+@tblName  
                        +' where '+@ID+' <(select min('+ @TempID +') from ('+ @SqlSelect+' top '+ CAST(@pageSize*(@page-1) as Varchar(20)) +' '+ @ID +' from '+@tblName  
                        +' where (1=1) ' + @strCondition +' order by '+ @fldSort +' '+ @strFSortType+') AS TBMinID)'  
                        +' '+ @strCondition +' order by '+ @fldSort +' '+ @strFSortType  
                end     
    end  
 /*-----返回查询结果-----*/  
set @strTmp = replace(replace(replace(@strTmp,'[FieldList]',@FieldList),'[TableList]',@TableList),'[WhereList]',@WhereList)  
exec sp_executesql @strTmp  
print @strTmp  
SET NOCOUNT OFF
GO

