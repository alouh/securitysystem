
CREATE VIEW dbo.SnmpItem
AS
SELECT dbo.NormalSet.ContrlID, dbo.NormalSet.ContrlStyle, dbo.NormalSet.PreContrlID, 
      dbo.NormalSet.PicIndex, dbo.SRitemSet.ShowName, dbo.SRitemSet.ShowCorR, 
      dbo.SRitemSet.ShowCorG, dbo.SRitemSet.ShowCorB, dbo.SRitemSet.ManagerMan, 
      dbo.SRitemSet.ManagerTel, dbo.SRitemSet.ManagerEmail, 
      dbo.SRitemSet.DeptName, dbo.SRitemSet.Scale, dbo.SRitemSet.LoadNetStyle, 
      dbo.SRitemSet.PointID, dbo.SRitemSet.PicPath, dbo.SRitemSet.RectL, 
      dbo.SRitemSet.PicID, dbo.SRitemSet.RectT, dbo.DeviceSys.Sys_OS, 
      dbo.SwitchInfo.Password, dbo.SwitchInfo.IP, dbo.SwitchInfo.MAC, 
      dbo.SwitchInfo.SWitchName, dbo.SwitchInfo.SystemName, 
      dbo.SwitchInfo.Description, dbo.SwitchInfo.Contact, dbo.SwitchInfo.Location, 
      dbo.SwitchInfo.SysObjectID, dbo.SwitchInfo.LastBoot, dbo.SwitchInfo.Router, 
      dbo.SRitemSet.RectR, dbo.SRitemSet.RectB, dbo.DeviceSys.Sys_Style, 
      dbo.DeviceSys.SwitchIP, dbo.DeviceSys.SwitchPort, dbo.DeviceSys.OnOff, 
      dbo.DeviceSys.PortDescr
FROM dbo.NormalSet INNER JOIN
      dbo.SRitemSet ON dbo.NormalSet.ContrlID = dbo.SRitemSet.ContrlID INNER JOIN
      dbo.SwitchInfo ON dbo.SRitemSet.ContrlID = dbo.SwitchInfo.ContrlID INNER JOIN
      dbo.DeviceSys ON dbo.SRitemSet.ContrlID = dbo.DeviceSys.ContrlID
GO

