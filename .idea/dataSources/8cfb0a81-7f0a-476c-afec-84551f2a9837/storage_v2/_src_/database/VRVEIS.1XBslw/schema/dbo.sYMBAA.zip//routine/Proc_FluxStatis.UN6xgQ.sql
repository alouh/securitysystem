CREATE PROCEDURE [dbo].[Proc_FluxStatis]
(
	@sqlQuery			VARCHAR(4000),  --sql语句
	@tempTable			VARCHAR(100),	--随机表名
	@pageSize			INT,			--每页显示数据条数
	@pageIndex			INT,			--当前页码
	@recordsCount		INT OUTPUT,				--记录数量
	@pagesCount			INT OUTPUT				--页数	
)
AS
BEGIN
	DECLARE 	@sql NVARCHAR(4000)
	DECLARE		@randTable VARCHAR(100)
	SET @randTable='temp'+@tempTable
		SET @sql='CREATE TABLE '+@randTable+
			'(Id [int] IDENTITY(1,1) NOT NULL,
				className VARCHAR(80) NULL,
				MyTotalFlux INT NULL,
				MyInFlux INT NULL,
				MyOutFlux INT NULL				
			)'
		PRINT @sql
		EXEC (@sql)	
	PRINT 1
	PRINT @sqlQuery
	SET @sql='INSERT INTO '+@randTable+'	'+(@sqlQuery)
	PRINT 2
	EXEC (@sql)
	PRINT 3
	SET NOCOUNT ON;
	SET @sql='SELECT * FROM	'+@randTable
	PRINT '123123'+@sql
	EXEC (@sql)
	SET @sql= 'SELECT @recordsCount=COUNT(0) FROM'+'	'+ @randTable
	EXEC SP_EXECUTESQL @sql,N'@recordsCount INT OUT',@recordsCount OUT
	IF @recordsCount%@pageSize=0
			SET @pagesCount=@recordsCount/@pageSize
		ELSE
			SET @pagesCount=@recordsCount/@pageSize+1	
	SET @sql= 'DROP TABLE '+'	'+@randTable
	EXEC (@sql)
END
GO

