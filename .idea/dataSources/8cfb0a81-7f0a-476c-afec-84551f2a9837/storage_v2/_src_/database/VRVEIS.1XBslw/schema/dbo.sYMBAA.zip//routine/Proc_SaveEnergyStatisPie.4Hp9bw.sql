CREATE PROCEDURE [dbo].[Proc_SaveEnergyStatisPie]
(
	@beginDateTime VARCHAR(50),
	@endDateTime	VARCHAR(50),
	@classIds	VARCHAR(2000),							--区域ClassId
	@groupIds	VARCHAR(2000),
	@monitor_Total		INT=0 OUTPUT, 				--显示器总和
	@suspend_Total		INT=0 OUTPUT,				--待机节能总和
	@sleep_Total		INT=0 OUTPUT,				--休眠节能总和
	@shutDown_Total	    INT=0 OUTPUT				--关机节能总和
)
AS
BEGIN
	DECLARE	@deviceType				INT,					--设备类型
			@monitor_Note			INT,					--笔记本显示器节能
			@suspend_Note			INT,					--笔记本待机节能
			@sleep_Note				INT,					--笔记本休眠节能
			@shutDown_Note			INT,					--笔记本关机节能
			@monitor_Desk			INT,					--台式机显示器节能
			@suspend_Desk			INT,					--台式机待机节能
			@sleep_Desk				INT,					--台式机休眠节能
			@shutDown_Desk			INT,					--台式机关机节能
			@deviceIdcondition		VARCHAR(1000),			--搜索DeviceId范围组合的查询条件
			@searchConditon			VARCHAR(1000),			-- 搜索条件，比如单位、部门
			@sum					INT,					--节能时间
			@sql					NVARCHAR(2000)
	SET @monitor_Total=0
	SET @suspend_Total=0
	SET @sleep_Total=0
	SET @shutDown_Total=0
	/*----查询获取笔记本，台式机 配置的节能数--*/
	SELECT @monitor_Note=[RunPower]
		  ,@suspend_Note=[StandbyPower]
		  ,@sleep_Note=[SleepPower]
		  ,@shutDown_Note=[DisplayPower]
		FROM PowerConfiguration
		WHERE WID=0
	SELECT @monitor_Desk=[RunPower]
		  ,@suspend_Desk=[StandbyPower]
		  ,@sleep_Desk=[SleepPower]
		  ,@shutDown_Desk=[DisplayPower]
		FROM PowerConfiguration
		WHERE WID=1
	/*----通过Classid以及GroupId 设置Device 搜索范围--*/
	IF (LEN(@classIds)=0)
			SET @classIds=-1
		/*----通过Classid以及GroupId 设置Device 搜索范围--*/
		IF (@classIds='-1')
			SET @deviceIdcondition='SELECT deviceId FROM Device d WHERE 1=1';
		IF (@classIds<>'-1')
			BEGIN				
				SET @deviceIdcondition='SELECT deviceId FROM Device d INNER JOIN class c ON d.classId=c.classId AND c.classId  in('+@classIds+')'
				IF (@groupIds<>'0')
					SET @deviceIdcondition=@deviceIdcondition+ 'UNION SELECT deviceId FROM dbo.Device d WHERE d.DeviceID IN (SELECT DeviceID FROM DistributeTemp WHERE TypeID in('+@groupIds+'))'
	END		
	/*----根据 页面输入 构造条件--*/
	SET @searchConditon='	AND	1=1	'
	IF LEN(@beginDateTime)>0
		SET @searchConditon=@searchConditon+'	AND	ClientTime >='''+@beginDateTime+''''
	IF LEN(@endDateTime)>0
		SET @searchConditon=@searchConditon+'	AND	ClientTime <='''+@endDateTime+''''
	/*----统计笔记本显示器节能 ExField3=10 --*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=10 AND ActionType =10005 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '笔记本显示器节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	PRINT '笔记本显示器节能SHIK'
	PRINT @sum
	SET @monitor_Total=@monitor_Total+@sum*@monitor_Note
	/*----统计台式机显示器节能 ExField3=3--*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=3 AND ActionType =10005 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '台式机显示器节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @monitor_Total=@monitor_Total+@sum*@monitor_Desk
	/*----统计笔记本待机节能 ExField3=10 --*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=10 AND ActionType =10007 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '笔记本待机节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @suspend_Total=@suspend_Total+@sum*@suspend_Note
	/*----统计台式机待机节能 ExField3=3 --*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=3 AND ActionType =10007 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '台式机待机节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @suspend_Total=@suspend_Total+@sum*@suspend_Desk
	/*----统计笔记本休眠节能 ExField3=10--*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=10 AND ActionType =10009 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '笔记本休眠节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @sleep_Total=@sleep_Total+@sum*@sleep_Note
	/*----统计台式机休眠节能 ExField3=3--*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=3 AND ActionType =10009 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '台式机休眠节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @sleep_Total=@sleep_Total+@sum*@sleep_Desk
	/*----统计笔记本关机节能 ExField3=10--*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=10 AND ActionType =10011 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '笔记本关机节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @shutDown_Total=@shutDown_Total+@sum*@shutDown_Note
	/*----统计台式机关机节能 ExField3=10--*/
	SET @sql='SELECT @sum=SUM(SustainMinute) FROM EnergyAuditEvent 	WHERE ExField3=3 AND ActionType =10011 AND DeviceId IN ('+@deviceIdcondition+') '+@searchConditon
	EXEC SP_EXECUTESQL @sql,N'@sum INT OUT',@sum OUT
	PRINT '台式机关机节能sql'
	PRINT @sql	
	IF @sum IS NULL
		SET @sum=0
	SET @shutDown_Total=@shutDown_Total+@sum*@shutDown_Desk
END
if not exists (select Tbl1.name from syscolumns as Tbl1,sysobjects as Tbl3 where Tbl1.id=Tbl3.id and Tbl3.name='DeviceLog' and Tbl1.name='OperatorId')
begin
	ALTER TABLE [dbo].[DeviceLog] Add [OperatorId] int
end
GO

