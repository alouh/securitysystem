CREATE PROCEDURE [dbo].[Proc_LocalStatisticView]
AS
Declare @strTmpForSecurity nvarchar(4000)         ----存放取得保密设备数量查询语句
Declare @strTmpForRegistered nvarchar(4000)       ----存放取得已注册设备数量查询语句
Declare @strTmpForAntivirus nvarchar(4000)        ----存放取得杀毒软件安装设备数量查询语句
Declare @strTmpForDeviceTotal nvarchar(4000)      ----存放取得设备总数查询语句
Declare @strTmpForUninstall nvarchar(4000)        ----存放取得客户端卸载数量查询语句
Declare @strTmpForWeakPassword nvarchar(4000)     ----存放取得弱口令数量查询语句
Declare @strTmp nvarchar(4000)                  ----存放取得查询结果总数的查询语句  
set @strTmpForSecurity =' Select ISNULL(count(*),0) from Device where Device.Registered=1 and Device.Reserved3&1=0 and  IsNull(Device.SeparateFlag,0)=0 and  Device.AgentVersion IN (select  CfgValue from VrveisConfig  where cfgname='+'''BaoMIAgentVersion'')'
set @strTmpForRegistered =' Select ISNULL(COUNT(*), 0) from Device where Device.Registered=1 and  Device.Reserved3&1=0 and  IsNull(Device.SeparateFlag,0)=0 '
set @strTmpForAntivirus =' select ISNULL(count(DeviceID),0) from Device where (RunLevel=2 or RunLevel=4) and Registered=1  and  Device.Reserved3&1=0 and  IsNull(Device.SeparateFlag,0)=0 '
set @strTmpForDeviceTotal =' select ISNULL(count(*),0) from Device where   Device.Reserved3&1=0 and  IsNull(Device.SeparateFlag,0)=0 '
set @strTmpForUninstall =' select ISNULL(count(*),0) from ErrorMessage inner join Device on ErrorMessage.DeviceID=Device.DeviceID where ErrorType=5 '
set @strTmpForWeakPassword =' select  ISNULL(count(*),0) from PMoveableDiskEvent inner join Device on PMoveableDiskEvent.OnlyID=Device.DeviceID where AuditTypeBigNum=5 and ExtNum=502 '
set @strTmp = @strTmpForSecurity+' union all '+ @strTmpForRegistered +' union all '+ @strTmpForAntivirus +' union all '+ @strTmpForDeviceTotal +' union all '+ @strTmpForUninstall +' union all '+@strTmpForWeakPassword
	/*-----返回查询结果-----*/
exec sp_executesql @strTmp
print @strTmp
SET NOCOUNT OFF
GO

