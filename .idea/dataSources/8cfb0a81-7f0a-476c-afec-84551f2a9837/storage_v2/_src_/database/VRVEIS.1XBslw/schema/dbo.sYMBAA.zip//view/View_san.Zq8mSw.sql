
CREATE VIEW dbo.View_san
AS
SELECT dbo.RegionScan.ScanID, dbo.RegionScan.RegID, dbo.RegionScan.ScanName, 
      dbo.RegionScan.ScanIP, dbo.IPRange.IPStart, dbo.IPRange.IPEnd, 
      dbo.RegionScan.ScanTime, dbo.IPRange.IsScan, dbo.IPRange.RangeID, 
      dbo.RegionScan.OrganCode, dbo.IPRange.IPMask, dbo.IPRange.Reserved1, 
      dbo.IPRange.Reserved2
FROM dbo.RegionScan INNER JOIN
      dbo.IPRange ON dbo.RegionScan.ScanID = dbo.IPRange.ScanID
GO

