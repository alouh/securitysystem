CREATE   PROCEDURE  [dbo].[Proc_GetCurrentUserPlicyKind]
	  @UserID int
AS
BEGIN
	SET NOCOUNT ON;
	declare  @GroupIdList varchar(100)   --用户权限组
	declare  @FuncIdList  nvarchar(200)   --当前菜单权限(临时)
	declare  @FuncIdListCount   nvarchar(200)  --当前菜单权限
	declare  @sqlScript    nvarchar(200)  --存放临时执行脚本
	set @GroupIdList=''
	set @FuncIdList=''
	set @FuncIdListCount=''
	set @sqlScript=''
	print  '1.获得用户ID  ok....'
    PRINT '@UserID:'+CAST(@UserID AS VARCHAR(10))
	print  ''
  set  @sqlScript= ' select  @GroupIdList=groupidlist from  users   where userid=@UserID'
  exec sp_executesql @sqlScript,N'@GroupIdList  varchar(100) output,@UserID int',@GroupIdList output,@UserID
  print  '2.获得权限组....'
  print  ' 权限组为:'+@GroupIdList
  print  ''
   declare  permissionCursor cursor  dynamic  for
   select   funcidlist  from    permissiongroup   where  permissiongroupid  in  (select * from f_split(@GroupIdList,';'))
   open  permissionCursor
	  fetch next from permissionCursor into @FuncIdList
	   set @FuncIdListCount=@FuncIdListCount+@FuncIdList
	   while(@@fetch_status=0)
	   begin
			fetch next from permissionCursor into @FuncIdList
			set @FuncIdListCount=@FuncIdListCount+@FuncIdList
	   end 
  close  permissionCursor
  deallocate permissionCursor
  if(@FuncIdListCount<>'')
  set  @FuncIdListCount=replace(@FuncIdListCount,';',',')  
  if(@FuncIdListCount<>'' and substring(@FuncIdListCount,len(@FuncIdListCount),1)=',')  --当最后一个字符是,号时,截断
	set @FuncIdListCount=substring(@FuncIdListCount,0,len(@FuncIdListCount))
  print '3.当前用户所有权限列表:'+@FuncIdListCount
  print  len(@FuncIdListCount)
  print ''
select * from   policy_Kind   where  policy_Kind in(
select   substring(remark,12,len(remark)) as policyType from   systemfunctions   where  funcid  in( select * from f_split(@FuncIdListCount,','))   and    patIndex('%/list.aspx%',functionlinkurl)>0
)
print  '4.查询完成..'
print ''
END
GO

