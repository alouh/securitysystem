/*
 说明：列头排序专用 为了配合列表列头排序而改写。旧方案只能按主键排序，不支持非主键排序。
  注意事项：1.@Sort 为排序方式，升序或降序，在程序中不要写死，应该是根据GridList列表控件的参数获取
            2.@fldSort参数不能包含表名 例如 "PMoveableDiskEvent.PEventID desc"不被允许，必须是"PEventID desc"
			3 如果需要排序的字段在多个表中出现，则会报错，必须指明排序字段属于哪个表，此时与第2点相背。
			  折中解决方案，就是使用表别名：
			    如：  @tblName = " (select a1,a2,a3,b1,b2,b3 from a inner join b on a.a1 =b.b4) as temp"
					  @fldName = "*"
				      @fldSort = " a1 desc"
					  @strCondition = "a2 > 100" 或者是 @strCondition = "temp.a2 > 100"
zxh 2014-02-12
*/
create PROC [dbo].[Proc_Pagination_Jointop_V2]
@tblName		NVARCHAR(4000),        --表名
@TableList      NVARCHAR(2000)=' ',    ----要替换的表或多个表的连接    
@fldName		NVARCHAR(4000),        --显示列名，如果是全部字段则为*
@FieldList      NVARCHAR(2000) = ' ',  ----要替换的字段列表   
@pageSize		INT =25,               --每页输出的记录数
@page			INT = 1,               --当前页数
@fldSort		VARCHAR(2000),         --排序 不含'order by'字符，如userid 
@Sort			INT,                   --排序规则 0:正序asc 1:倒序desc 
@strCondition	NVARCHAR(4000),        --查询条件 不含'where'字符，如id>10 and len(userid)>9
@WhereList		NVARCHAR(2000) = ' ',  --要替换的查询条件   
@ID				VARCHAR(100),          --单一主键或唯一值键
@Dist			INT,                   --记录总数 0:会返回总记录
@pageCount		INT OUTPUT,            --返回总页数
@Counts			INT OUTPUT             --记返回总记录
AS
SET NOCOUNT ON
IF ISNULL(@Counts,'') = '' SET @Counts = 0
SET @fldSort = RTRIM(LTRIM(@fldSort))
SET @ID = RTRIM(LTRIM(@ID))
SET @strCondition=RTRIM( LTRIM(@strCondition))
WHILE CHARINDEX(', ',@fldSort) > 0 OR CHARINDEX(' ,',@fldSort) > 0
BEGIN
SET @fldSort = REPLACE(@fldSort,', ',',')
SET @fldSort = REPLACE(@fldSort,' ,',',')
END
IF ISNULL(@fldSort,'') =''
	SET @fldSort = @ID     --如果未设备排序字段，则按主键排序
IF ISNULL(@tblName,'') = '' OR ISNULL(@fldName,'') = ''
OR ISNULL(@ID,'') = ''
OR @Sort < 0 OR @Sort > 1
OR @Dist < 0 OR @Dist > 1 
OR @pageSize < 0 OR @page < 0
BEGIN
   PRINT('ERR_00参数错误')
   RETURN
END
DECLARE @TempID VARCHAR(100)
DECLARE @strDistinct VARCHAR(20)
DECLARE @new_where1 NVARCHAR(4000)
DECLARE @new_order1 VARCHAR(2000)
DECLARE @new_order2 VARCHAR(2000)
DECLARE @Sql NVARCHAR(4000)
DECLARE @SqlCount NVARCHAR(4000)
DECLARE @SortType VARCHAR(10)
IF @Dist =1
	SET @strDistinct =' DISTINCT '
ELSE
	SET @strDistinct = ' '
IF ISNULL(@strCondition,'') = ''
BEGIN
SET @new_where1 = ' '
END
ELSE
BEGIN
IF UPPER( LEFT(@strCondition,4)) ='AND '  --去掉where参数中的最前面的and 
	SET @strCondition = RIGHT(@strCondition,LEN(@strCondition)-4)
SET @new_where1 = ' WHERE  ' + @strCondition
END
IF @Sort = 1
	SET @SortType =  'DESC'
ELSE
    SET @SortType =  'ASC'
/*初始化@fldSort参数*/
SET @fldSort =LTRIM(RTRIM(@fldSort))
IF CHARINDEX(',',@fldSort) > 0
	SET @fldSort = RTRIM(LTRIM(SUBSTRING(@fldSort,1,CHARINDEX(',',@fldSort) - 1))) --去掉 分隔符之后的内容 如 "UpTime Desc,PEventID" => "UpTime Desc"
IF CHARINDEX(' ',@fldSort) > 0
	SET @fldSort = RTRIM(LTRIM(SUBSTRING(@fldSort,1,CHARINDEX(' ',@fldSort) - 1))) --去掉 desc 或 asc 如  "UpTime Desc" =>  "PMoveableDiskEvent.UpTime"
IF CHARINDEX('.',@fldSort) > 0
  BEGIN
   IF CHARINDEX('dbo',@fldSort) < 0           ---自定义函数不能截取
	SET @fldSort= RTRIM( LTRIM(SUBSTRING(@fldSort,CHARINDEX('.',@fldSort)+1,LEN(@fldSort)))) --去表名前辍
  end
IF CHARINDEX('.',@ID) > 0
	SET @ID  = RTRIM( LTRIM(SUBSTRING(@ID,CHARINDEX('.',@ID)+1,LEN(@ID)))) --去表名前辍
IF(UPPER(@fldSort) = UPPER(@ID))
	SET @fldSort = @fldSort + ' ' + @SortType
ELSE
    SET @fldSort = @fldSort + ' ' + @SortType + ',' + @ID + ' ASC' -- 非主键排序也必须追加主键 asc,否则排序随机不稳定
SET @new_order1 = ' ORDER BY ' + @fldSort
SET @new_order2 = @fldSort + ','
SET @new_order2 = REPLACE(REPLACE(@new_order2,'ASC,','{ASC},'),'DESC,','{DESC},')
SET @new_order2 = REPLACE(REPLACE(@new_order2,'{ASC},','DESC,'),'{DESC},','ASC,')
SET @new_order2 = ' ORDER BY ' + SUBSTRING(@new_order2,1,LEN(@new_order2)-1)
SET @SqlCount = 'SELECT @Counts=COUNT('+ @strDistinct + @ID +'),@pageCount=CEILING((COUNT('+ @strDistinct +@ID+')+0.0)/'+ STR(@pageSize)+') FROM ' + @tblName + @new_where1
SET @SqlCount = REPLACE(REPLACE(REPLACE(@SqlCount,'[FieldList]',@FieldList),'[TableList]',@TableList),'[WhereList]',@WhereList)      
IF @Counts = 0 
BEGIN
	EXEC SP_EXECUTESQL @SqlCount,N'@Counts INT OUTPUT,@pageCount INT OUTPUT',@Counts OUTPUT,@pageCount OUTPUT
END
ELSE
BEGIN
	SELECT @Counts = @Counts,@pageCount=CEILING((@Counts+0.0)/@pageSize)
END
IF @page > CEILING((@Counts+0.0)/@pageSize)
BEGIN
	SET @page = CEILING((@Counts+0.0)/@pageSize)
END
IF @page = 1 OR @page >= CEILING((@Counts+0.0)/@pageSize)
BEGIN
			IF @page = 1 --返回第一页数据
			BEGIN
				SET @Sql = 'SELECT '+ @strDistinct +' TOP ' + STR(@pageSize) + ' ' + @fldName + ' FROM '+ @tblName + @new_where1 + @new_order1
			END
			IF @page >= CEILING((@Counts+0.0)/@pageSize) --返回最后一页数据
			BEGIN
				SET @Sql = 'SELECT  TOP ' + STR(@pageSize) + ' * FROM ('
						+ 'SELECT '+ @strDistinct + ' TOP ' + STR(ABS(@pageSize*@page-@Counts-@pageSize))
						+ ' ' + @fldName + ' FROM '
						+ @tblName + @new_where1 + @new_order2 + ' ) AS TMP '
						+ @new_order1
		   END
END
ELSE
BEGIN
		IF @page <= CEILING((@Counts+0.0)/@pageSize)/2 --正向检索
		BEGIN
			SET @Sql = 'SELECT TOP ' + STR(@pageSize) + ' * FROM ( '
			+ 'SELECT TOP ' + STR(@pageSize) + ' * FROM ( '
			+ ' SELECT ' +@strDistinct + '  TOP ' + STR(@pageSize * @page) + ' ' + @fldName
			+ ' FROM ' + @tblName + @new_where1 + @new_order1 + ' ) AS TMP '
			+ @new_order2 + ' ) AS TMP ' + @new_order1
		END
		ELSE --反向检索
		BEGIN
			SET @Sql = 'SELECT TOP ' + STR(@pageSize) + ' * FROM ( '
			+ 'SELECT TOP ' + STR(@pageSize) + '* FROM ( '
			+ ' SELECT ' + @strDistinct + '  TOP ' + STR( @Counts - @pageSize * @page + @pageSize) + ' ' + @fldName
			+ ' FROM ' + @tblName + @new_where1 + @new_order2 + ' ) AS TMP '
			+ @new_order1 + ' ) AS TMP ' + @new_order1
		END
END
SET @Sql = REPLACE(REPLACE(REPLACE(@Sql,'[FieldList]',@FieldList),'[TableList]',@TableList),'[WhereList]',@WhereList)      
print @Sql
EXEC(@Sql)
GO

