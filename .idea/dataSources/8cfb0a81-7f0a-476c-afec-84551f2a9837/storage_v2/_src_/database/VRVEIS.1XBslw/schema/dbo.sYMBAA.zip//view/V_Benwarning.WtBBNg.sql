
CREATE VIEW dbo.V_Benwarning
AS
SELECT dbo.Class.ClassID, dbo.Class.UpID, dbo.Class.ClassName, 
      dbo.ErrorMessage.ErrorID, dbo.ErrorMessage.ErrorTime, 
      dbo.ErrorMessage.ErrorType, dbo.ErrorMessage.IPAddress, 
      dbo.ErrorMessage.ErrorMsg, dbo.ErrorMessage.MacAddress, 
      dbo.ErrorMessage.DeviceName, dbo.ErrorMessage.Identify, 
      dbo.ErrorMessage.IPAddress1, dbo.ErrorMessage.DeptName, 
      dbo.ErrorMessage.OfficeName, dbo.ErrorMessage.UserName, dbo.Class.ClassCode, 
      dbo.ErrorType.ErrorName
FROM dbo.Class INNER JOIN
      dbo.Device ON dbo.Class.ClassID = dbo.Device.ClassID INNER JOIN
      dbo.ErrorMessage ON 
      dbo.Device.DeviceID = dbo.ErrorMessage.DeviceID INNER JOIN
      dbo.ErrorType ON dbo.ErrorMessage.ErrorType = dbo.ErrorType.ErrorType
GO

