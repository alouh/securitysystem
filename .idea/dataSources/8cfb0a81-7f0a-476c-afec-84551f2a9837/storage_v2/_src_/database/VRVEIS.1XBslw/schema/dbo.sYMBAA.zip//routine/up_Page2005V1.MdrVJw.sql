CREATE PROCEDURE [dbo].[up_Page2005V1] 
    @TableName varchar(50),        --表名
 @Fields varchar(5000) = '*',    --字段名(全部字段为*) 如果要查的字段是自增字段不用放进来，默认已经在第一个字段产生自增字段
 @OrderField varchar(5000),        --排序字段(支持多字段，不用加order by)
 @sqlWhere varchar(5000) = Null,--条件语句(不用加where)
 @pageSize int,                    --每页多少条记录
 @pageIndex int = 1 ,            --指定当前为第几页
 @totalRecord int = 0 output,
 @TotalPage int output            --返回总页数
AS
BEGIN
 Begin Tran --开始事务
    Declare @sql nvarchar(4000); 
 if @totalRecord<=0 begin
        if (@SqlWhere='' or @sqlWhere=NULL)
            set @sql = 'select @totalRecord = count(*) from ' + @TableName
        else
            set @sql = 'select @totalRecord = count(*) from ' + @TableName + ' with(nolock) where ' + @sqlWhere
        EXEC sp_executesql @sql,N'@totalRecord int OUTPUT',@totalRecord OUTPUT--计算总记录数       
    end
    select @TotalPage=CEILING((@totalRecord+0.0)/@PageSize)
    if @PageIndex<=0 
        Set @pageIndex = 1
    if @pageIndex>@TotalPage
        Set @pageIndex = @TotalPage
    Declare @StartRecord int
    Declare @EndRecord int
    set @StartRecord = (@pageIndex-1)*@PageSize + 1
    set @EndRecord = @StartRecord + @pageSize - 1
Declare @orderby nvarchar(100);
if(charindex('order',@OrderField) > 0)
 SELECT @orderby = @OrderField
else
 SELECT @orderby = ' order by ' + @OrderField
Declare @tmpTable varchar(20)
SET @tmpTable ='#tmp'
 if (@SqlWhere='' or @sqlWhere=NULL)
begin
SELECT @sql = 'SELECT BindId AS RowIndex,'
SELECT @sql = @sql + rtrim(@Fields) + ' INTO  '+ @tmpTable 
SELECT @sql = @sql + ' FROM  '+rtrim(@TableName) + @orderby
SELECT @sql = @sql + ' '+'SELECT RowIndex,'+ rtrim(@Fields) +' FROM ' + @tmpTable 
SELECT @sql = @sql + ' WHERE  RowIndex BETWEEN ' + Convert(char,@StartRecord) + ' AND ' + Convert(char,@EndRecord)
SELECT @sql = @sql + ' '+'DROP TABLE '+@tmpTable
end
else
begin
SELECT @sql = 'SELECT BindId AS RowIndex,'
SELECT @sql = @sql + rtrim(@Fields) + ' INTO  '+ @tmpTable 
SELECT @sql = @sql + ' FROM  '+rtrim(@TableName)+' where 0=0 AND ' + @SqlWhere + @orderby
SELECT @sql = @sql + ' '+'SELECT RowIndex,'+ rtrim(@Fields) +' FROM ' + @tmpTable 
SELECT @sql = @sql + ' WHERE  RowIndex BETWEEN ' + Convert(char,@StartRecord) + ' AND ' + Convert(char,@EndRecord)
SELECT @sql = @sql + ' '+'DROP TABLE '+@tmpTable
end
     print @sql   
    Exec(@Sql)
    If @@Error <> 0
      Begin
        RollBack Tran
        Return -1
      End
     Else
      Begin
        Commit Tran
        Return @totalRecord ---返回记录总数
      End   
END
GO

