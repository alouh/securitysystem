
CREATE VIEW dbo.View_process
AS
SELECT dbo.RunProcStatus.RunID, dbo.RunProcStatus.ProcessID, 
      dbo.RunProcStatus.DeviceID, dbo.RunProcStatus.RunTime, 
      dbo.View_devis.DeviceName, dbo.View_devis.IPAddres, 
      dbo.View_devis.MacAddress, dbo.View_devis.ClassName, dbo.View_devis.ClassID, 
      dbo.View_devis.RegName, dbo.View_devis.RegID, dbo.View_devis.Registered, 
      dbo.View_devis.RunStatus, dbo.View_devis.RegIP, dbo.View_devis.DeptName, 
      dbo.View_devis.Protect, dbo.View_devis.Reserved1, dbo.View_devis.Reserved2, 
      dbo.View_devis.Reserved3, dbo.View_devis.Reserved4, dbo.View_devis.Reserved5, 
      dbo.View_devis.Reserved8, dbo.View_devis.Reserved7, dbo.View_devis.Reserved6, 
      dbo.View_devis.DeviceCode, dbo.View_devis.DeviceStatus, 
      dbo.View_devis.RunLevel, dbo.View_devis.Forceout, dbo.View_devis.Locked, 
      dbo.View_devis.NumIPAddress, dbo.View_devis.AliasName, 
      dbo.View_devis.AgentVersion, dbo.View_devis.SwitchPort, dbo.View_devis.SwitchIP, 
      dbo.View_devis.SwitchName, dbo.View_devis.OfficeName, 
      dbo.View_devis.FloorNumber, dbo.View_devis.RoomNumber, dbo.View_devis.Other, 
      dbo.View_devis.CPU, dbo.View_devis.Memory, dbo.View_devis.DiskSize, 
      dbo.View_devis.Identify, dbo.View_devis.AllowDail, dbo.View_devis.RegisterTime, 
      dbo.View_devis.UserName, dbo.View_devis.Tel, dbo.View_devis.Email, 
      dbo.View_devis.LastTime, dbo.View_devis.UpID, dbo.View_devis.OSType
FROM dbo.RunProcStatus INNER JOIN
      dbo.View_devis ON dbo.RunProcStatus.DeviceID = dbo.View_devis.DeviceID
GO

