
CREATE VIEW dbo.V_WarnCount
AS
SELECT PEventID AS EventID, OnlyID, DeviceName, IPAddress, IPNum, MacAddress, 
      ClassID, ClassName, PolicyID, PolicyName, ExtNum AS EventTypeID, Description, 
      UpTime, ClientTime, Reserved1, Reserved2, 1 AS WarningType
FROM dbo.PMoveableDiskEvent
GO

