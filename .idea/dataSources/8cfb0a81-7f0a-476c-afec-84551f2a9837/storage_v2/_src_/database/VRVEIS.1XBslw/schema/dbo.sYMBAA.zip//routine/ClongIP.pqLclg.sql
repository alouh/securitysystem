CREATE FUNCTION [dbo].[ClongIP] (@RealIP varchar(50))  
RETURNS BIGINT AS  
BEGIN 
	declare @ResultIP BIGINT
if CharIndex(';',@RealIP)>0 
 begin 
	set @RealIP=left(@RealIP,CharIndex(';',@RealIP)-1)  
 end
if CharIndex('-',@RealIP)>0 
 begin 
	set @RealIP=left(@RealIP,CharIndex('-',@RealIP)-1)  
 end
		select @ResultIP=left(@RealIP,CharIndex('.',@RealIP)-1)*Cast(256*256*256 as bigint)+Substring(@RealIP,CharIndex('.',@RealIP)+1,CharIndex('.',@RealIP,CharIndex('.',@RealIP)+1)-CharIndex('.',@RealIP)-1)*Cast(256*256 as bigint)+Reverse(Substring(Reverse(@RealIP),CharIndex('.',Reverse(@RealIP))+1,CharIndex('.',Reverse(@RealIP),CharIndex('.',Reverse(@RealIP))+1)-CharIndex('.',Reverse(@RealIP))-1))*Cast(256 as bigint)+Right(@RealIP,CharIndex('.',Reverse(@RealIP))-1)
		return  @ResultIP
END
GO

