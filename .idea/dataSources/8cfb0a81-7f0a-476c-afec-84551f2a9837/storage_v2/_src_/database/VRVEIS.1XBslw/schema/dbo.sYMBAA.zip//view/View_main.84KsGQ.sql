
CREATE VIEW dbo.View_main
AS
SELECT dbo.View_Scan.ClassID, dbo.View_Scan.ClassName, dbo.IPRange.IPStart, 
      dbo.IPRange.IPEnd, dbo.View_Scan.RegID, dbo.View_Scan.RegName, 
      dbo.View_Scan.ScanName, dbo.View_Scan.ScanIP, dbo.View_Scan.IPStart AS Expr1, 
      dbo.View_Scan.IPEnd AS Expr2, dbo.Principal.PrincipalName, 
      dbo.View_Scan.RegIP
FROM dbo.View_Scan INNER JOIN
      dbo.IPRange ON dbo.View_Scan.ClassID = dbo.IPRange.ClassID INNER JOIN
      dbo.Principal ON dbo.View_Scan.ClassID = dbo.Principal.ClassID
GO

