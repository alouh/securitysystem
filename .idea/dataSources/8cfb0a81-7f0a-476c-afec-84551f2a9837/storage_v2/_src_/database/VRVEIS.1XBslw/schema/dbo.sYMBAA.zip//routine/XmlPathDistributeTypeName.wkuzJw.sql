CREATE FUNCTION XmlPathDistributeTypeName
(
	@DeviceID numeric(18,0)
)
RETURNS varchar(8000)
AS
BEGIN
	DECLARE @s varchar(8000)
    set @s = ';'
    select @s = @s +CONVERT(varchar,  d.TypeName)+';' from DistributeTemp t inner join DistributeType d on t.typeID=d.id where t.DeviceID=@DeviceID
	if(@s=';')
	begin
	  set @s =NULL
	end
	return @s;
END
GO

