CREATE VIEW dbo.View_device
AS
SELECT dbo.Device.DeviceID, dbo.Device.ClassID, dbo.Class.UpID, dbo.Class.ClassName, dbo.Device.RegID, dbo.RegionManage.RegName, dbo.RegionManage.RegIP, 
                      dbo.Device.DeptName, dbo.Device.OfficeName, dbo.Device.SubOffice, dbo.Device.UserName, dbo.Device.Tel, dbo.Device.Email, dbo.Device.NumIPAddress, 
                      dbo.Device.IPAddres, dbo.Device.RouteIPAddress, dbo.Device.MacAddress, dbo.Device.DeviceName, dbo.Device.AliasName, dbo.Device.SwitchIP, 
                      dbo.Device.SwitchPort, dbo.Device.SwitchName, dbo.Device.DeviceDesc, dbo.Device.LogonUserName, dbo.Device.DomainName, dbo.Device.Registered, 
                      dbo.Device.RunStatus, dbo.Device.Locked, dbo.Device.Protect, dbo.Device.Forceout, dbo.Device.RunLevel, dbo.Device.KvsCompany, dbo.Device.OSType, 
                      dbo.Device.RoomNumber, dbo.Device.DeviceCode, dbo.Device.FloorNumber, dbo.Device.PolicemenKind, dbo.Device.DiskSerial, dbo.Device.Migrate, 
                      dbo.Device.CPU, dbo.Device.Memory, dbo.Device.DiskSize, dbo.Device.Identify, dbo.Device.AllowDail, dbo.Device.RegisterTime, dbo.Device.LastTime, 
                      dbo.Device.Other, dbo.Device.AgentVersion, dbo.Device.Reserved1, dbo.Device.Reserved2, dbo.Device.Reserved3, dbo.Device.Reserved4, dbo.Device.Reserved5, 
                      dbo.Device.Reserved6, dbo.Device.Reserved7, dbo.Device.Reserved8, dbo.Device.DeviceStatus, dbo.Device.Description, dbo.Device.ProductID, 
                      dbo.Device.KvsVersion, dbo.Device.UnInstallTime, dbo.Device.SpNumber, dbo.Device.IEVersion, dbo.Device.CpuType, dbo.Device.IsIntelAMT, 
                      dbo.Device.IntelAMTMode, dbo.Device.IntelAMTIP, dbo.Device.IsLocal, dbo.Device.AclCtrl, dbo.Device.AttackTime, dbo.Device.LockedEndTime, 
                      dbo.Device.ProtectEndTime, dbo.Device.SetupTmos, dbo.Device.MigrateRegIP, dbo.Device.MigrateUnitName, dbo.Device.MigrateTime, dbo.Device.IdleTime, 
                      dbo.Device.PortDescr, dbo.Device.OsLanguage, dbo.Device.DevOnlyID, dbo.Device.ReportTime
FROM dbo.Device WITH(NOLOCK) INNER JOIN
                      dbo.RegionManage WITH(NOLOCK) ON dbo.Device.RegID = dbo.RegionManage.RegID Left JOIN
                      dbo.Class WITH(NOLOCK) ON dbo.Device.ClassID = dbo.Class.ClassID
GO

