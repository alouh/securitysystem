
CREATE VIEW dbo.View_userqx
AS
SELECT dbo.Users.UserID, dbo.Users.UserName, dbo.UserAccess.ClassID, 
      dbo.Class.ClassName, dbo.Class.UpID, dbo.UserAccess.Rights, 
      dbo.Users.PassWord, dbo.Users.Type, dbo.UserAccess.AccessID, 
      dbo.Class.Description3, dbo.Class.Description2, dbo.Class.Description1, 
      dbo.Class.ScanPreType, dbo.Class.PreventType, dbo.Class.HostUrl2, 
      dbo.Class.HostUrl1, dbo.Class.ClassCode, dbo.Users.ParentID, 
      dbo.Users.Description
FROM dbo.Class INNER JOIN
      dbo.UserAccess ON dbo.Class.ClassID = dbo.UserAccess.ClassID INNER JOIN
      dbo.Users ON dbo.UserAccess.UserID = dbo.Users.UserID
GO

