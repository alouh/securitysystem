CREATE VIEW [dbo].[View_DeviceClass]
AS
SELECT     dbo.Class.ClassName, dbo.Device.* FROM    dbo.Class INNER JOIN   dbo.Device ON dbo.Class.ClassID = dbo.Device.ClassID
GO

