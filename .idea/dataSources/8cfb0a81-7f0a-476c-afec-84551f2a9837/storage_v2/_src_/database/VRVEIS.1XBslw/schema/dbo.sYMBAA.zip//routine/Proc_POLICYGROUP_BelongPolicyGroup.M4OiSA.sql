CREATE PROCEDURE [dbo].[Proc_POLICYGROUP_BelongPolicyGroup]
(
 @TableType  VARCHAR(500),      ----要操作的表 Policy_List 还是 Policy_List_NOPASS
 @STR    VARCHAR(500)      ----组合策略删除的id
)
AS
begin
SET NOCOUNT ON
declare @cursor cursor;  ---游标
DECLARE @Policy_ID int;  --策略id
DECLARE @BelongPolicyGroup VARCHAR(500);
 if(@TableType = 'Policy_List')
    begin
		set @cursor=cursor for 
		select Policy_ID,BelongPolicyGroup from Policy_List where BelongPolicyGroup like ''+'%;'+@STR+'' or BelongPolicyGroup like ''+@STR+';%'+'' or BelongPolicyGroup like ''+'%;'+@STR+';%'+'' or BelongPolicyGroup = @STR
		open @cursor 
		fetch next from @cursor into @Policy_ID,@BelongPolicyGroup;
		while @@FETCH_STATUS=0
		begin
		  if(charindex(''+';'+@STR+';'+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+';'+@STR+'','')  where Policy_ID = @Policy_ID
		  end
		  else if(charindex(''+';'+@STR+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+';'+@STR+'','')  where Policy_ID = @Policy_ID
		  end
		  else if(charindex(''+@STR+';'+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+@STR+';'+'','')  where Policy_ID = @Policy_ID
		  end
		  else if(charindex(''+@STR+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+@STR+'','')  where Policy_ID = @Policy_ID
		  end
		  fetch next from @cursor into @Policy_ID,@BelongPolicyGroup;
		end
		close @cursor
		deallocate @cursor
    end
 else
  begin
		set @cursor=cursor for 
		select Policy_ID,BelongPolicyGroup from Policy_List_NOPASS where BelongPolicyGroup like ''+'%;'+@STR+'' or BelongPolicyGroup like ''+@STR+';%'+'' or BelongPolicyGroup like ''+'%;'+@STR+';%'+'' or BelongPolicyGroup = @STR
		open @cursor 
		fetch next from @cursor into @Policy_ID,@BelongPolicyGroup;
		while @@FETCH_STATUS=0
		begin
		  if(charindex(''+';'+@STR+';'+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List_NOPASS  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+';'+@STR+'','')  where Policy_ID = @Policy_ID
		  end
		  else if(charindex(''+';'+@STR+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List_NOPASS  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+';'+@STR+'','')  where Policy_ID = @Policy_ID
		  end
		  else if(charindex(''+@STR+';'+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List_NOPASS  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+@STR+';'+'','')  where Policy_ID = @Policy_ID
		  end
		  else if(charindex(''+@STR+'',@BelongPolicyGroup)>0)
		  begin
			 update  Policy_List_NOPASS  set BelongPolicyGroup= replace(@BelongPolicyGroup,''+@STR+'','')  where Policy_ID = @Policy_ID
		  end
		  fetch next from @cursor into @Policy_ID,@BelongPolicyGroup;
		end
		close @cursor
		deallocate @cursor
  end
SET NOCOUNT OFF
end
GO

