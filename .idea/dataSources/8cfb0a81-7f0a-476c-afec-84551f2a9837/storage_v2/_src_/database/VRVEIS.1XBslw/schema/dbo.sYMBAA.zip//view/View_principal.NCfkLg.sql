
CREATE VIEW dbo.View_principal
AS
SELECT dbo.Principal.PrincipalID, dbo.Class.ClassID, dbo.Class.ClassName, 
      dbo.Principal.PrincipalName, dbo.Principal.Tel, dbo.Principal.Email, 
      dbo.Class.UpID
FROM dbo.Class LEFT OUTER JOIN
      dbo.Principal ON dbo.Class.ClassID = dbo.Principal.ClassID
GO

