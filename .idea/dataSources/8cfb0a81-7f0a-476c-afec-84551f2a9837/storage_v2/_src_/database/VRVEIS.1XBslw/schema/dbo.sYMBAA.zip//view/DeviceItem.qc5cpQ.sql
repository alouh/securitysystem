
CREATE VIEW dbo.DeviceItem
AS
SELECT dbo.Device.UserName, dbo.Device.SwitchIP, 
      dbo.Device.DeviceName, dbo.Device.SwitchPort, 
      dbo.Device.OSType, dbo.Device.IPAddres, 
      dbo.Device.MacAddress, dbo.Device.Tel, 
      dbo.Device.Email, dbo.Device.RunStatus, 
      dbo.Device.ContrlID, 
      dbo.SnmpItem.PreContrlID, dbo.SnmpItem.PicIndex, dbo.SnmpItem.ContrlStyle, 
      dbo.SnmpItem.ShowCorR, dbo.SnmpItem.ShowCorG, dbo.SnmpItem.ShowCorB, 
      dbo.SnmpItem.ShowName, dbo.Device.DeptName, dbo.SnmpItem.Scale, 
      dbo.SnmpItem.PointID, dbo.SnmpItem.PicPath, dbo.SnmpItem.RectL, 
      dbo.SnmpItem.PicID, dbo.SnmpItem.RectT, dbo.SnmpItem.SystemName, 
      dbo.SnmpItem.Description, dbo.SnmpItem.Contact, dbo.SnmpItem.Location, 
      dbo.SnmpItem.SysObjectID, dbo.SnmpItem.LastBoot, dbo.SnmpItem.Router, 
      dbo.SnmpItem.RectR, dbo.SnmpItem.RectB, dbo.SnmpItem.SWitchName
FROM dbo.SnmpItem CROSS JOIN
      dbo.Device
WHERE (IsNull(dbo.Device.ContrlID,0)= 0) OR
      (dbo.SnmpItem.ContrlID = dbo.Device.ContrlID)
GO

