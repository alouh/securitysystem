
Create View V_AuditEvent As
Select PEventID,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],Version,Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PSoftInfoEvent' as TableName From PSoftInfoEvent
Union
Select PEventID,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],'' as Version,0 as Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PMoveableDiskEvent' as TableName From PMoveableDiskEvent
Union
Select PEventID,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],'' as Version,0 as Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PSecretEvent' as TableName From PSecretEvent
Union
Select PEventID,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],'' as Version,0 as Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PSafeCheckEvent' as TableName From PSafeCheckEvent
Union
Select PEventID,OnlyID,DeviceName,IpAddress,IpNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],'' as Version,0 as Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PRunInfoEvent' as TableName From PRunInfoEvent
Union
Select PEventID,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],'' as Version,0 as Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PProtectEvent' as TableName From PProtectEvent
Union
Select PEventID,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassID,ClassName,PolicyID,PolicyName,ExtNum,[Description],'' as Version,0 as Disabled,UpTime,ClientTime,AuthUserName,LookFlag,Reserved1,Reserved2,'PHttpKbMouseEvent' as TableName From PHttpKbMouseEvent
GO

