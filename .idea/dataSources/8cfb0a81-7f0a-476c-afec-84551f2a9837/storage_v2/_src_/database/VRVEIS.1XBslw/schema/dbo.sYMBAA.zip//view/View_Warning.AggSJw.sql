
CREATE VIEW dbo.View_Warning
AS
SELECT dbo.MapWarning.ErrID, dbo.MapWarning.RegID, dbo.MapWarning.OrganCode, 
      dbo.MapWarning.OrganName, dbo.ErrorType.ErrorName, dbo.MapWarning.ErrType, 
      dbo.MapWarning.Duration, dbo.MapWarning.DeviceName, 
      dbo.MapWarning.IPAddress, dbo.MapWarning.MacAddress, 
      dbo.MapWarning.ErrContent, dbo.MapWarning.ErrTime
FROM dbo.MapWarning INNER JOIN
      dbo.ErrorType ON dbo.MapWarning.ErrType = dbo.ErrorType.ErrorType
GO

