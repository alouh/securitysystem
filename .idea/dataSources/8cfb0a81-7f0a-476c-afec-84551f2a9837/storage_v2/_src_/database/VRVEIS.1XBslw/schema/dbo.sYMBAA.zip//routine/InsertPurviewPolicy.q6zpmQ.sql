create PROCEDURE  [dbo].[InsertPurviewPolicy]
@PType varchar(200),
@CanWrite int,
@UserName VARCHAR(50),
@flag int output
AS
BEGIN
SET NOCOUNT ON;
DECLARE  @UserId int
declare  @IsExitPolicy int 
declare  @sqlstr VARCHAR(2000)
set @UserId=(select UserId from Users where UserName=@UserName)
if ISNULL(@UserId,'') = ''  or(@UserId=0)
   begin
    set @sqlstr=''
   set  @flag=2
   end
else
  begin
    set  @IsExitPolicy=(select count(*) from PurviewPolicy  where PolicyType=@PType and UserID=@UserId)
     if @isExitPolicy=0
begin
      set   @sqlstr='insert into PurviewPolicy(PolicyType,CanWrite,UserID) values ('''+@PType+''','+CAST(@CanWrite as varchar(1))+','+CAST(@UserId as varchar(4))+')'
       set  @flag=0
end
      else
begin 
       set  @sqlstr='update PurviewPolicy set CanWrite='+CAST(@CanWrite as varchar(1))+' where  PolicyType='''+@PType+''' and UserID='+CAST(@UserId as varchar(4))+''  
       set   @flag=1
end
  end
END
IF NOT EXISTS (SELECT * FROM RESSTRING  WHERE Name= '031904' and LangID='zh-cn')
insert into RESSTRING  (Name,LangID,Value) values ('031904','zh-cn','摆渡工具策略')
GO

