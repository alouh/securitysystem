
CREATE VIEW dbo.LineItem
AS
SELECT dbo.LineInfo.LineStyle, dbo.LineInfo.LineWidth, dbo.LineInfo.LineCorR, 
      dbo.LineInfo.LineCorG, dbo.LineInfo.LineCorB, dbo.LineInfo.DeviceID1, 
      dbo.LineInfo.DeviceID2, dbo.LineInfo.Point1X, dbo.LineInfo.Point1Y, 
      dbo.LineInfo.Point2X, dbo.LineInfo.Point2Y, dbo.NormalSet.ContrlID, 
      dbo.NormalSet.PreContrlID, dbo.NormalSet.ContrlStyle, dbo.NormalSet.PicIndex
FROM dbo.LineInfo INNER JOIN
      dbo.NormalSet ON dbo.LineInfo.ContrlID = dbo.NormalSet.ContrlID
GO

