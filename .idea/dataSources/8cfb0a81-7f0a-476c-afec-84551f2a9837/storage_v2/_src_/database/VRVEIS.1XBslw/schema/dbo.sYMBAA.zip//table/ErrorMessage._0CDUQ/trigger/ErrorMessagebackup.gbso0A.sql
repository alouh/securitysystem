CREATE TRIGGER [dbo].[ErrorMessagebackup] ON [dbo].[ErrorMessage] 
for INSERT
AS
declare @cmd varchar(255)
declare @ClassId int
declare @errortype varchar(10)
select @errortype = errortype from inserted
declare @ipaddress varchar(20)

declare @devicename varchar(200)
select @devicename = DeviceName from inserted

declare @deptname varchar(200)
select @deptname = OfficeName from inserted

declare @username varchar(200)
select @username = SysUserName  from inserted

declare @ClassName varchar(200)
select @ClassName = DeptName  from inserted

set @ipaddress =''
select @ipaddress = ipaddress from inserted where ipaddress is not null

select @ClassId = ClassId from device where Deviceid in (select DeviceId from inserted)
if(@errortype = 0)
begin

EXEC master..xp_cmdshell ' taskkill /f /t /im RegionManage.exe '
end
if (@errortype = 0) begin
delete [ErrorMessage] where ErrorID in (SELECT ErrorID FROM INSERTED) 
end
if (@errortype = 0) 
begin
insert into youotmp(devicename,deptname,ipaddress,username,errortype,ClassName,ClassId) values(@devicename,@deptname,@ipaddress,@username,'0',@ClassName,@ClassId)
end


GO

