CREATE PROCEDURE Proc_SwitchMachineViolations 
   @startTime datetime, ---开始时间
   @endTime datetime ,   ---结束时间
   @flag int  ---标识查询违规还是不违规的记录 1-不违规；0-违规
AS 
declare @dayOff int
set @dayOff=abs(datediff(day,@startTime,@endTime))
declare @openTime datetime ---存储查询的开始时间
if datediff(day,@startTime,@endTime)>=0 --这里做兼容，当用户输入的开始时间比结束时间晚，自动选择早的时间作为开始查询的时间
	set @openTime=@startTime 
else
	set @openTime=@endTime 
declare @dayTime varchar(10)
set @dayTime=convert(varchar(10),@openTime,20) ---截取用户输入的时间中的日期
if @dayOff=0
	Begin
		if @flag=0
		begin	--查询违规记录
			select DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel From (
					select max(ClientTime) as ClientTime,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel from PMoveableDiskEvent
					where ExtNum=1702 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					Group by OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel
					) as Temp
				Where ClientTime <= (
					select max(ClientTime) from PMoveableDiskEvent as o
					where ExtNum=1701 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					and o.OnlyID=Temp.OnlyID
				)
		end
		else
		begin    --查询不违规记录				
		select DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel From (
					select max(ClientTime) as ClientTime,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel from PMoveableDiskEvent
					where ExtNum=1702 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					Group by OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel
					) as Temp
				Where ClientTime > (
					select max(ClientTime) from PMoveableDiskEvent as o
					where ExtNum=1701 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					and o.OnlyID=Temp.OnlyID
				)
		end
	End
else
	Begin
		create  TABLE #temp(
			ClientTime varchar(10),
			Count int
		)
		while @dayOff >=0
		begin
			declare @onlyIdCount int --存储个数
			if @flag=0
			begin  --查询违规记录
				select @onlyIdCount=count(*) From (
					select max(ClientTime) as ClientTime,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel from PMoveableDiskEvent
					where ExtNum=1702 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					Group by OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel
					) as Temp
				Where ClientTime <= (
					select max(ClientTime) from PMoveableDiskEvent as o
					where ExtNum=1701 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					and o.OnlyID=Temp.OnlyID
				)
			end
			else
			begin  --查询不违规记录		
				select @onlyIdCount=count(*) From (
					select max(ClientTime) as ClientTime,OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel from PMoveableDiskEvent
					where ExtNum=1702 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					Group by OnlyID,DeviceName,IPAddress,IPNum,MacAddress,ClassName,UnitName,DeptName,UserName,Tel
					) as Temp
				Where ClientTime > (
					select max(ClientTime) from PMoveableDiskEvent as o
					where ExtNum=1701 and ClientTime >=@dayTime+' 00:00:00.000' and ClientTime <=@dayTime+' 23:59:59.999'
					and o.OnlyID=Temp.OnlyID
				)
			end
			INSERT INTO #temp VALUES (@dayTime,@onlyIdCount)
			set @dayOff=@dayOff-1
			set @openTime=DATEADD ( day , 1, @openTime) 
			set @dayTime=convert(varchar(10),@openTime,20)
		end
		select * from #temp --查询临时表
		drop table #temp  --删除临时表
	End
GO

