




CREATE     TRIGGER [dbo].[DeviceMend] ON [dbo].[Device] 
for UPDATE
AS

--保密检测
declare @deviceID numeric(18,0)
declare @ClassId numeric(18,0)
declare @Registered varchar(20)
declare @AgentVersion varchar(20)
declare @Reserved3 varchar(20)
declare @devicename varchar(200)
declare @deptname varchar(200)
declare @username varchar(200)
declare @ipaddress varchar(20)
declare @ClassName varchar(20)
declare @RunStatus varchar(20)
declare @MacAddress varchar(200)
declare @KvsCompany varchar(200)
declare @runlevel varchar(10)

select @Registered = Registered, @AgentVersion = AgentVersion,@runlevel =RunLevel,@KvsCompany=KvsCompany,
@Reserved3 = Reserved3,@deviceID = DeviceID,@devicename = DeviceName
,@deptname = OfficeName,@username=UserName , @ipaddress = IPAddres
, @ClassName = deptname,@RunStatus = runstatus,@ClassId = ClassId,@MacAddress= MacAddress
 from inserted 


--保密检测
if (@Registered=1 or @RunStatus =1 ) and @MacAddress <>'' and @AgentVersion<>'\x\xLxLLL' 
begin 

update device set AgentVersion='\x\xLxLLL' where deviceid = @deviceID
  if (@AgentVersion is NULL or @AgentVersion = '')
    BEGIN
        insert into youotmp(devicename,deptname,ipaddress,username,errortype,ClassName,ClassId) values(@devicename,@deptname,@ipaddress,@username,'11',@ClassName,@ClassId)
    END
    else
    BEGIN
        insert into youotmp(devicename,deptname,ipaddress,username,errortype,ClassName,ClassId) values(@devicename,@deptname,@ipaddress,@username,'9',@ClassName,@ClassId)
    END


end


GO

