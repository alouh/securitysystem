Create PROCEDURE [dbo].[Proc_QueryEnergyAudit]
(
	@pageSize INT,							--每页显示数据条数
	@pageIndex INT,							--当前页码
	@tableRand	VARCHAR(50),				--表名称 随机数
	@searchDeptName   VARCHAR(100),			--部门名
	@searchTel		VARCHAR(100),			--电话
	@searchUserName   VARCHAR(100),			--用户
	@searchUnitName VARCHAR(100),			--单位名
	@beginTime  VARCHAR(100),				--开始时间
	@endTime    VARCHAR(100),				--结束时间
	@beginIp    VARCHAR(100),				--起始IP
	@endIp      VARCHAR(100),				--结束IP
	@classIds	VARCHAR(2000),				--区域ClassId
	@groupIds	VARCHAR(2000),
	@recordsCount INT OUTPUT,				--记录数量
	@pagesCount	  INT OUTPUT				--页数	
)
AS	
	BEGIN	
		DECLARE 
				@deviceId   VARCHAR(20),			--终端ID
				@monitor	INT,					--显示器节能
				@suspend	INT,					--待机节能
				@sleep		INT,					--休眠节能
				@shutDown	INT,					--关机节能
				@total		INT,					--耗能总数
				@tempTable	  VARCHAR(100),			--临时表名
				@deptName	  VARCHAR(80),			--单位名称
				@officeName	  VARCHAR(64),			--部门名称
				@userName	  VARCHAR(64),			--用户名
				@tel		  VARCHAR(50),			--电话	
				@IpAddress	  VARCHAR(300),			--Ip地址
				@deviceType	  INT,					--设备类型
				@monitor_Note	INT,				
				@suspend_Note	INT,
				@sleep_Note		INT,
				@shutDown_Note	INT,
				@monitor_Desk	INT,				
				@suspend_Desk	INT,
				@sleep_Desk		INT,
				@shutDown_Desk	INT,
				@deviceIdcondition	VARCHAR(1000),  --搜索DeviceId范围组合的查询条件
				@searchConditon		VARCHAR(1000),  -- 搜索条件，比如单位、部门
				@count				INT,	
				@sql		    NVARCHAR(2000)
		SELECT @monitor_Note=[RunPower]
			  ,@suspend_Note=[StandbyPower]
			  ,@sleep_Note=[SleepPower]
			  ,@shutDown_Note=[DisplayPower]
			FROM PowerConfiguration
			WHERE WID=0
		SELECT @monitor_Desk=[RunPower]
			  ,@suspend_Desk=[StandbyPower]
			  ,@sleep_Desk=[SleepPower]
			  ,@shutDown_Desk=[DisplayPower]
			FROM PowerConfiguration
			WHERE WID=1
		IF (LEN(@classIds)=0)
			SET @classIds=-1
		IF (@classIds='-1')
			SET @deviceIdcondition='SELECT deviceId FROM Device d WHERE 1=1';
		IF (@classIds<>'-1')
			BEGIN				
				SET @deviceIdcondition='SELECT deviceId FROM Device d INNER JOIN class c ON d.classId=c.classId AND c.classId  in('+@classIds+')'
				IF (@groupIds<>'0')
					SET @deviceIdcondition=@deviceIdcondition+ 'UNION SELECT deviceId FROM dbo.Device d WHERE d.DeviceID IN (SELECT DeviceID FROM DistributeTemp WHERE TypeID in('+@groupIds+'))'
			END		
		SET @searchConditon='	AND	1=1	'
		IF LEN(@searchDeptName)>0
			SET @searchConditon=@searchConditon+'	AND	DeptName	LIKE ''%'+@searchDeptName+'%'''
		IF LEN(@searchTel)>0
			SET @searchConditon=@searchConditon+'	AND	Tel	LIKE ''%'+@searchTel+'%'''
		IF LEN(@searchUserName)>0
			SET @searchConditon=@searchConditon+'	AND	UserName	LIKE ''%'+@searchUserName+'%'''
		IF LEN(@searchUnitName)>0
			SET @searchConditon=@searchConditon+'	AND	UnitName	LIKE ''%'+@searchUnitName+'%'''
		IF LEN(@beginTime)>0
			SET @searchConditon=@searchConditon+'	AND	ClientTime >='''+@beginTime+''''
		IF LEN(@endTime)>0
			SET @searchConditon=@searchConditon+'	AND	ClientTime <='''+@endTime+''''
		IF LEN(@beginIp)>0
			SET @searchConditon=@searchConditon+'	AND	IPAddress >='''+@beginIp+''''
		IF LEN(@endIp)>0
			SET @searchConditon=@searchConditon+'	AND	IPAddress <='''+@endIp+''''
		SET @sql='SELECT @recordsCount=COUNT(DISTINCT(deviceId)) FROM  EnergyAuditEvent WHERE ExField3 IN (3,10) AND DeviceId IN ('+@deviceIdcondition+')' +@searchConditon												
		EXEC SP_EXECUTESQL @sql,N'@recordsCount INT OUT',@recordsCount OUT
		IF @recordsCount%@pageSize=0
			SET @pagesCount=@recordsCount/@pageSize
		ELSE
			SET @pagesCount=@recordsCount/@pageSize+1
		SET @tempTable='temp'+@tableRand
		SET @sql='CREATE TABLE '+@tempTable+
			'(Id [int] IDENTITY(1,1) NOT NULL,
				DeptName VARCHAR(80) NULL,
				OfficeName VARCHAR(64) NULL,
				UserName VARCHAR(64) NULL,
				Tel	VARCHAR(50) NULL,
				IPAddres VARCHAR(300) NULL,
				Monitor	INT NULL,
				suspend	INT	NULL,
				sleep	INT NULL,
				shutedDown INT NULL,
				Total		INT NULL,
				DeviceType	INT	NULL				
			)'
		PRINT @sql
		EXEC (@sql)		
		DECLARE cur CURSOR FOR SELECT DISTINCT EnergyAuditEvent.DeviceID,EnergyAuditEvent.ExField3 
			FROM EnergyAuditEvent left join Device on Device.DeviceID = EnergyAuditEvent.DeviceID
		OPEN cur
			FETCH cur INTO @deviceId,@deviceType
			PRINT 'FETCH_STATUS'
			PRINT 	@@FETCH_STATUS				
			WHILE (@@FETCH_STATUS=0)
				BEGIN					
						SET @sql='SELECT @count=COUNT(*) FROM  EnergyAuditEvent WHERE DeviceId IN ('+@deviceIdcondition+')' +@searchConditon												
						EXEC SP_EXECUTESQL @sql,N'@count INT OUT',@count OUT
						IF @count=0
							CONTINUE
						SET @sql='SELECT @monitor=SUM(SustainMinute) FROM EnergyAuditEvent	WHERE ActionType =10005 AND  DeviceId='+@deviceId+''+@searchConditon
						PRINT @sql
						EXEC SP_EXECUTESQL @sql,N'@monitor INT OUT',@monitor OUT
						IF @monitor IS NULL
							SET @monitor=0
						PRINT '@monitor VALUE IS '
						PRINT @monitor
						SET @sql='SELECT @suspend=SUM(SustainMinute) FROM EnergyAuditEvent  WHERE ActionType =10007	 AND DeviceId='+@deviceId+''+@searchConditon
						EXEC SP_EXECUTESQL @sql,N'@suspend INT OUT',@suspend OUT
						IF @suspend IS NULL
							SET @suspend=0
						PRINT '@suspend'
						PRINT @suspend
						SET @sql='SELECT @sleep=SUM(SustainMinute) FROM EnergyAuditEvent    WHERE ActionType =10009 AND DeviceId='+@deviceId+''+@searchConditon
						EXEC SP_EXECUTESQL @sql,N'@sleep INT OUT',@sleep OUT
						IF @sleep IS NULL
							SET @sleep=0
						SET @sql='SELECT @shutDown=SUM(SustainMinute) FROM EnergyAuditEvent WHERE ActionType =10011	AND  DeviceId='+@deviceId+''+@searchConditon
						EXEC SP_EXECUTESQL @sql,N'@shutDown INT OUT',@shutDown OUT
						IF @shutDown IS NULL
							SET @shutDown=0
						PRINT 'SET @deptName=officeName'
						SELECT @deptName=officeName,
								@officeName=deptName,
								@userName=userName,
								@tel=tel,
								@IpAddress=IpAddres
							FROM Device
							WHERE deviceId=@deviceId
						IF @deptName IS NULL
							PRINT 1
						ELSE
							PRINT 0
						IF (@deviceType=3)
							BEGIN
								SET @monitor=@monitor*@monitor_Desk
								SET @suspend=@suspend*@suspend_Desk
								SET @sleep=@sleep*@sleep_Desk
								SET @shutDown=@shutDown*@shutDown_Note
								SET @total=@suspend+@sleep+@shutDown+@monitor
							END
						ELSE IF (@deviceType=10)
							BEGIN
								SET @monitor=@monitor*@monitor_Desk
								SET @suspend=@suspend*@suspend_Desk
								SET @sleep=@sleep*@sleep_Desk
								SET @shutDown=@shutDown*@shutDown_Note
								SET @total=@suspend+@sleep+@shutDown+@monitor
							END
						ELSE
							BEGIN
								SET @deviceType=-1
								SET @monitor=0
								SET @suspend=0
								SET @sleep=0
								SET @shutDown=0
								SET @total=0
							END
						IF @deviceType<>-1
						BEGIN
							SET @sql='INSERT INTO '+@tempTable+'(DeptName,OfficeName,UserName,Tel,IPAddres,Monitor,suspend,sleep,shutedDown,Total,DeviceType)VALUES('''+@deptName+''','''+@officeName+''','''+@userName+''','''+@tel+''','''+@IpAddress+''','+CAST(isnull(@monitor,0) AS VARCHAR(200))+','+CAST(isnull(@suspend,0) AS VARCHAR(200))+','+CAST(isnull(@sleep,0) AS VARCHAR(200))+','+CAST(isnull(@shutDown,0) AS VARCHAR(200))+','+CAST(isnull(@total,0) AS VARCHAR(200))+','+CAST(isnull(@deviceType,'') AS VARCHAR(200))+')'
							PRINT '插入临时表的Sql'+@sql
							EXEC (@sql)
						END
				FETCH cur INTO @deviceId,@deviceType
				END		
		CLOSE cur
		DEALLOCATE cur
		SET @sql='SELECT TOP '+CAST(@pageSize AS VARCHAR(4))+' * FROM '+@tempTable+'	WHERE id>'+CAST((@pageIndex-1)*@pageSize AS VARCHAR(4))
		PRINT @sql
		EXEC (@sql)
		EXEC ('DROP TABLE '+@tempTable)  	
	END
GO

