
CREATE VIEW dbo.FontItem
AS
SELECT dbo.FontSet.ShowName, dbo.FontSet.TitleCorR, dbo.FontSet.TitleCorG, 
      dbo.FontSet.TitleCorB, dbo.FontSet.PointX, dbo.FontSet.PointY, dbo.FontSet.RectL, 
      dbo.FontSet.RectT, dbo.FontSet.RectR, dbo.FontSet.RectB, dbo.FontSet.Fheight, 
      dbo.FontSet.Fwidth, dbo.FontSet.FEscapement, dbo.FontSet.FOrientation, 
      dbo.FontSet.Fweight, dbo.FontSet.FlfItalic, dbo.FontSet.FlfUnderline, 
      dbo.FontSet.FlfStrikeOut, dbo.FontSet.FlfCharSet, dbo.FontSet.FlfOutPrecision, 
      dbo.FontSet.FlfClipPrecision, dbo.FontSet.FlfQuality, dbo.FontSet.FlfPitchAndFamily, 
      dbo.FontSet.FlfFaceName, dbo.NormalSet.ContrlID, dbo.NormalSet.ContrlStyle, 
      dbo.NormalSet.PreContrlID, dbo.NormalSet.PicIndex
FROM dbo.FontSet INNER JOIN
      dbo.NormalSet ON dbo.FontSet.ContrlID = dbo.NormalSet.ContrlID
GO

