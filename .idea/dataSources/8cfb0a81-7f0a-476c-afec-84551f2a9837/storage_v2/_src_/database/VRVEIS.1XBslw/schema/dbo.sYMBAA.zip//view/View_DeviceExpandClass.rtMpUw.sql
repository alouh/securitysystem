create VIEW View_DeviceExpandClass
AS
SELECT      A.ClassName, B.DeviceID
,B.DevOnlyID,B.OnlyID,B.ClassID,B.ContrlID,B.DeviceCode,B.RegID,B.RegionCode,B.DeptName,B.OfficeName,B.FloorNumber,B.RoomNumber,
B.SubOffice,B.UserName,B.DeviceName,B.AliasName,B.SwitchID,B.SwitchName,B.SwitchIP,B.SwitchPort,B.PortDescr,B.OSVersion,B.OSType,
B.OsLanguage,B.SpNumber,B.IEVersion,B.CpuType,B.CpuSerial,B.NumIPAddress,B.Hardware1,B.Hardware2,B.IPAddres,B.MacAddress,B.RouteIPAddress,
B.NetWork,B.CPU,B.Memory,B.DiskSize,B.Other,B.SynStatus,B.ManualTag,B.Tel,B.Email,B.LogonUserName,B.DomainName,B.Identify,B.AllowDail,
B.RegisterTime,B.LastTime,B.AttackTime,B.ReportTime,B.UnInstallTime,B.IdleTime,B.BootTime,B.ProtectEndTime,B.LockedEndTime,
B.HealthTime,B.OnlineTime,B.TotalTime,B.DayTime,B.RunStatus,B.Registered,B.AgentVersion,B.KvsCompany,B.KvsVersion,B.AclCtrl,B.ServiceNo,
B.DiskSerial,B.ProductID,B.CountPatchLevel0,B.CountPatchLevel1,B.CountPatchLevel2,B.CountPatchLevel3,B.CountPatchLevel4,B.ValidDay,
B.HealthScore,B.LoginCount,B.TioStatus,B.SeparateFlag,B.Protect,B.Locked,B.Forceout,B.RunLevel,B.DeviceStatus,B.IsLocal,B.Reserved1,B.Reserved2,
B.Reserved3,B.Reserved4,B.Reserved5,B.Reserved6,B.Reserved7,B.Reserved8,B.Migrate,B.MigrateRegIP,B.MigrateUnitName,B.MigrateTime,B.PolicemenKind,
B.IntelAMTMode,B.IntelAMTIP,B.IsIntelAMT,B.AMTUUID,B.AMTVersion,B.REGIP,B.FirwallStatus,B.Description,B.ComputerManufacturer,B.ComputerModel,
B.ExternalDevice,B.ExternalDeviceModel,B.RoomSerial,B.DeviceNumber,B.PKI,B.Pkid,B.PkiUser,B.PkiUnit,B.ActUser,B.ActiveNetCard,B.DeviceDesc,B.FwPolicy,
B.AllOss,B.SetupTmos,B.ExField1,B.ExField2,B.ExField3,B.ExField4,B.ExField5, 
			   D.ExFlag3,D.ExFlag5,D.ExFlag6,D.ExFlag7,D.ExFlag8,D.ExFlag9,D.ExFlag10,D.ExFlag11,D.ExFlag12,D.ExField3 as DeviceExpandExField3,D.ExField4 as DeviceExpandExField4,
			   E.DevSecondType,	
			   clientuser.cusername,
			   dbo.XmlPathClientGroupName(clientuser.CuserID) as  GroupName,
			   dbo.XmlPathClientGroupID(clientuser.CuserID) as GroupID,		  
               dbo.GetProtectCodeByDeviceID(B.DeviceID,C.OrganCode)  AS ProtectCode,
			   dbo.XmlPathDistributeTypeName(B.DeviceID)  AS DistributeTypeName,
			   DefString = (  SELECT CommonList.DefString  --设备用途
		                      FROM   CommonList  
		                      WHERE  CommonList.DefType =1 AND CommonList.DefID = B.Reserved6
		                   )
	FROM       dbo.Class A
			   INNER JOIN  dbo.Device B ON B.ClassID = A.ClassID  
			   INNER JOIN dbo.RegionManage C ON C.RegID = B.RegID
			   lEFT JOIN  dbo.DeviceExpand D ON D.DeviceID = B.DeviceID  
			   lEFT JOIN  dbo.DeviceTypeList E on E.DevTypeCode = B.Reserved2
               Left Join clientuser On B.ExField1 =clientuser.CuserName
GO

