CREATE VIEW dbo.V_Patch
AS
SELECT DISTINCT PatchCode FROM dbo.PatchIndex WHERE (PatchPath NOT IN (SELECT PatchName FROM dbo.NoSetupPatch))
GO

