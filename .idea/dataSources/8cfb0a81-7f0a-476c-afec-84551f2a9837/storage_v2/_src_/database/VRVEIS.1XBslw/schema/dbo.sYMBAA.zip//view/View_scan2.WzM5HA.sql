
CREATE VIEW dbo.View_scan2
AS
SELECT dbo.RegionManage.ClassID, dbo.Class.ClassName, dbo.RegionManage.RegID, 
      dbo.RegionManage.RegName, dbo.RegionScan.ScanID, 
      dbo.RegionScan.ScanName
FROM dbo.Class INNER JOIN
      dbo.RegionManage ON dbo.Class.ClassID = dbo.RegionManage.ClassID INNER JOIN
      dbo.RegionScan ON dbo.RegionManage.RegID = dbo.RegionScan.RegID
GO

