
CREATE VIEW dbo.View_Scan
AS
SELECT dbo.RegionScan.ScanID, dbo.Class.ClassID, dbo.Class.ClassName, 
      dbo.RegionManage.RegName, dbo.RegionScan.ScanName, dbo.RegionScan.ScanIP, 
      dbo.IPRange.IPStart, dbo.IPRange.IPEnd, dbo.Class.UpID, dbo.RegionScan.ScanTime, 
      dbo.RegionManage.RegIP, dbo.RegionManage.RegID, 
      dbo.RegionScan.OrganCode
FROM dbo.IPRange INNER JOIN
      dbo.RegionScan ON 
      dbo.IPRange.ScanID = dbo.RegionScan.ScanID RIGHT OUTER JOIN
      dbo.Class LEFT OUTER JOIN
      dbo.RegionManage ON dbo.Class.ClassID = dbo.RegionManage.ClassID ON 
      dbo.RegionScan.RegID = dbo.RegionManage.RegID
GO

