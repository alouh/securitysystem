CREATE FUNCTION [dbo].[f_IP2Int](@ip varchar(50))
RETURNS bigint AS
BEGIN
	DECLARE @re bigint
	SET @re=0
	SELECT @re=@re+LEFT(@ip,CHARINDEX('.',@ip+'.')-1)*ID ,@ip=STUFF(@ip,1,CHARINDEX('.',@ip+'.'),'')
	FROM(
	SELECT ID=CAST(16777216 as bigint)
	UNION  ALL SELECT 65536
	UNION  ALL SELECT 256
	UNION  ALL SELECT 1)A
	RETURN(@re)
END
GO

