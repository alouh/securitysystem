
CREATE VIEW dbo.View_patch
AS
SELECT dbo.SystemPatch.PatchID, dbo.SystemPatch.DeviceID, 
      dbo.View_device.DeviceName, dbo.SystemPatch.PatchName, 
      dbo.SystemPatch.PatchVersion, dbo.SystemPatch.PatchTime, 
      dbo.View_device.ClassID, dbo.View_device.UpID, dbo.View_device.ClassName, 
      dbo.View_device.RegID, dbo.View_device.RegName, dbo.View_device.IPAddres, 
      dbo.View_device.DeptName, dbo.View_device.OfficeName, 
      dbo.View_device.FloorNumber, dbo.View_device.RoomNumber, 
      dbo.View_device.Reserved8, dbo.View_device.Reserved7, 
      dbo.View_device.Reserved6, dbo.View_device.Locked, dbo.View_device.MacAddress, 
      dbo.View_device.CPU, dbo.View_device.Memory, dbo.View_device.DiskSize, 
      dbo.View_device.Identify, dbo.View_device.AllowDail, dbo.View_device.RegisterTime, 
      dbo.View_device.UserName, dbo.View_device.Tel, dbo.View_device.Email, 
      dbo.View_device.LastTime, dbo.View_device.OSType, dbo.View_device.Other, 
      dbo.View_device.SwitchName, dbo.View_device.SwitchIP, 
      dbo.View_device.SwitchPort, dbo.View_device.Registered, 
      dbo.View_device.RunStatus, dbo.View_device.AgentVersion, dbo.View_device.RegIP, 
      dbo.View_device.Protect, dbo.View_device.Reserved1, dbo.View_device.Reserved2, 
      dbo.View_device.Forceout, dbo.View_device.RunLevel, 
      dbo.View_device.DeviceStatus, dbo.View_device.NumIPAddress, 
      dbo.View_device.AliasName, dbo.View_device.DeviceCode, 
      dbo.View_device.Reserved5, dbo.View_device.Reserved4, 
      dbo.View_device.Reserved3
FROM dbo.View_device INNER JOIN
      dbo.SystemPatch ON dbo.View_device.DeviceID = dbo.SystemPatch.DeviceID
GO

