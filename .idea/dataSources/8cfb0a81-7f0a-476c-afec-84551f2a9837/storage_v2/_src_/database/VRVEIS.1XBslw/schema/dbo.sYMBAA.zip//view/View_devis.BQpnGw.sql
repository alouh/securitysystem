
CREATE VIEW dbo.View_devis
AS
SELECT dbo.Device.DeviceID, dbo.Class.ClassName, dbo.Device.DeviceName, 
      dbo.Device.IPAddres, dbo.Device.MacAddress, dbo.Device.CPU, dbo.Device.Memory, 
      dbo.Device.DiskSize, dbo.Device.Identify, dbo.Device.AllowDail, 
      dbo.Device.RegisterTime, dbo.Device.UserName, dbo.Device.Tel, dbo.Device.Email, 
      dbo.Device.LastTime, dbo.Class.UpID, dbo.Device.OSType, dbo.Device.ClassID, 
      dbo.Device.DeptName, dbo.Device.OfficeName, dbo.Device.FloorNumber, 
      dbo.Device.RoomNumber, dbo.Device.Other, dbo.Device.SwitchName, 
      dbo.Device.SwitchIP, dbo.Device.SwitchPort, dbo.Device.RunStatus, 
      dbo.Device.Registered, dbo.Device.AgentVersion, dbo.RegionManage.RegName, 
      dbo.Device.RegID, dbo.RegionManage.RegIP, dbo.Device.Protect, 
      dbo.Device.Reserved1, dbo.Device.Reserved2, dbo.Device.Reserved3, 
      dbo.Device.Reserved4, dbo.Device.Reserved5, dbo.Device.AliasName, 
      dbo.Device.NumIPAddress, dbo.Device.Locked, dbo.Device.Forceout, 
      dbo.Device.RunLevel, dbo.Device.DeviceStatus, dbo.Device.DeviceCode, 
      dbo.Device.Reserved6, dbo.Device.Reserved7, dbo.Device.Reserved8
FROM dbo.Device INNER JOIN
      dbo.RegionManage ON dbo.Device.RegID = dbo.RegionManage.RegID INNER JOIN
      dbo.Class ON dbo.Device.ClassID = dbo.Class.ClassID
GO

