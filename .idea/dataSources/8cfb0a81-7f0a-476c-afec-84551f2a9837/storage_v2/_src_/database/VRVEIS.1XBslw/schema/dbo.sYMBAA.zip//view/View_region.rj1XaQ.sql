
CREATE VIEW dbo.View_region
AS
SELECT dbo.Class.ClassName, dbo.Prevents.PreventName, dbo.Class.UpID, 
      dbo.Class.ClassID, dbo.RegionManage.RegID, dbo.RegionManage.RegIP, 
      dbo.RegionManage.RegName, dbo.RegionManage.RemoteIP, 
      dbo.RegionManage.DetectTime, dbo.RegionManage.UpdateVersion, 
      dbo.RegionManage.PreventType, dbo.RegionManage.ScanPreType, 
      dbo.RegionManage.OrganCode
FROM dbo.Prevents INNER JOIN
      dbo.RegionManage ON 
      dbo.Prevents.PreventType = dbo.RegionManage.PreventType INNER JOIN
      dbo.Class ON dbo.RegionManage.ClassID = dbo.Class.ClassID
GO

