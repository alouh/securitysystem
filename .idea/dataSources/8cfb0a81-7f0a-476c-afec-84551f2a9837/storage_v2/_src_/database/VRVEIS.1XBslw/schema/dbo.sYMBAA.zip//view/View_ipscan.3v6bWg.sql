
CREATE VIEW dbo.View_ipscan
AS
SELECT dbo.RegionScan.ScanID, dbo.Class.ClassName, dbo.RegionScan.RegID, 
      dbo.RegionManage.RegName, dbo.RegionScan.ScanIP, dbo.RegionScan.ScanName, 
      dbo.Class.UpID, dbo.RegionManage.ClassID, dbo.RegionScan.ScanTime
FROM dbo.Class INNER JOIN
      dbo.RegionManage ON dbo.Class.ClassID = dbo.RegionManage.ClassID INNER JOIN
      dbo.RegionScan ON dbo.RegionManage.RegID = dbo.RegionScan.RegID
GO

