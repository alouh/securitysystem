CREATE PROCEDURE [dbo].[vrv_hourproblems] AS

/*统计每小时报告问题的计算机数*/

declare @strTime varchar(20)
declare @strSubTime varchar(20)
declare @strTimeA varchar(20)
declare @strTimeB varchar(20)
declare @strTimec varchar(20)
declare @strFlag varchar(20)

select              @strTime = Dateadd(Hh, - 1, getdate())
select              @strSubTime = datename(Mm, @strTime) + '/' + datename(Dd, @strTime) + ' ' + datename(Hh, @strTime) + ':00'
select              @strTimeA = datename(Yy, @strTime) + '-' + datename(Mm, @strTime) + '-' + datename(Dd, @strTime) + ' ' + datename(Hh, @strTime) + ':00:00'
select              @strTimeB = datename(Yy, @strTime) + '-' + datename(Mm, @strTime) + '-' + datename(Dd, @strTime) + ' ' + datename(Hh, @strTime) + ':59:59'
select              @strFlag = '24problems'

delete from PastStatus where execTime=@strTimeA and CfgFlag= @strFlag
insert into PastStatus(subTime,execTime,CfgValue1,CfgValue2,CfgValue3,CfgFlag) 
select @strSubTime, @strTimeA, CountVirus,CountPatch,CountErr,@strFlag from 
(SELECT COUNT(DISTINCT Virus.DeviceID) AS CountVirus FROM Virus inner join device on virus.deviceid = device.deviceid where Device.Registered = 1 and  DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440 and VirusTime between @strTimeA and @strTimeB) as t1 
left join (select COUNT(DeviceID) AS CountPatch FROM  Device WHERE  Registered = 1 and  DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440 and (CountPatchLevel3 <> 0) OR(CountPatchLevel4 <> 0)) as t2 on 1=1 
left join (SELECT     COUNT(DISTINCT ErrorMessage.DeviceID) AS CountErr FROM ErrorMessage inner join Device on ErrorMessage.DeviceID=Device.DeviceID where  Device.Registered = 1 and  DATEDIFF(Mi, Device.ReportTime, GETDATE()) <= 1440 and ErrorType in (0,1,2,4,8) and ErrorTime between @strTimeA and @strTimeB) as t3 on 1=1
GO

