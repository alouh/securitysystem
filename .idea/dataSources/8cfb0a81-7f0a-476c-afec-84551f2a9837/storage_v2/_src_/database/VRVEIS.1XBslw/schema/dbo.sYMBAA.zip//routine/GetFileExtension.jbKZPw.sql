create function GetFileExtension(@FileName as varchar(500))
returns varchar(500) as
begin
    declare @extension varchar(500)
    set @extension=substring(@fileName,charindex('.',@fileName)+1,len(@fileName))
    set @extension = substring(@extension,0,charindex('.',@extension))
    if not exists(select 1 where datalength(@extension)=0)  ----判断只有一个点的时候
    return @extension
    return @FileName
end
GO

