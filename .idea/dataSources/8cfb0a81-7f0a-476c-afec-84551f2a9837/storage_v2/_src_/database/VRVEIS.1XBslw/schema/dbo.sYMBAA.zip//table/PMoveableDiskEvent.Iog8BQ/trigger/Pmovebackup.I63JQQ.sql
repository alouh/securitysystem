
CREATE TRIGGER [dbo].[Pmovebackup] ON [dbo].[PMoveableDiskEvent] 
for INSERT
AS
declare @cmd varchar(255)
declare @errortype varchar(10)
declare @out int
declare @cmd2 varchar(200)
select @errortype = 7
--
declare @extnum varchar(20)
select @extnum = extnum from inserted
--设备名称
declare @devicename varchar(2248)
declare @description varchar(2048)
declare @ClassId numeric(18,0)
select @devicename = DeviceName,@ClassId = ClassId ,@description =Description from inserted

select @devicename = @devicename + ',' + cast(@description as varchar)

--部门名称
declare @ClassName varchar(200)
select @ClassName = ClassName from inserted

--部门名称
declare @deptname varchar(200)
select @deptname = DeviceName from inserted

--用户名
declare @username varchar(200)

select @username=AuthUserName from inserted

--ip地址
declare @ipaddress varchar(20)
set @ipaddress =''
select @ipaddress = ipaddress from inserted where ipaddress is not null

declare @PeventID int 
SELECT @PeventID=PEventID FROM INSERTED
if (@extnum = 502) 
begin
 delete from [PMoveableDiskEvent] where PEventID = @PEventID
 insert into youotmp(devicename,deptname,ipaddress,username,errortype,ClassName,ClassId) values(@devicename,@deptname,@ipaddress,@username,'7',@ClassName,@ClassId)

end

GO

