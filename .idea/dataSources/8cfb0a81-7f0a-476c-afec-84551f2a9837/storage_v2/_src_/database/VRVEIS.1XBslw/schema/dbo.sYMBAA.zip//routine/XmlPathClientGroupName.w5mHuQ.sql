CREATE FUNCTION XmlPathClientGroupName
(
	@UserID int
)
RETURNS varchar(8000)
AS
BEGIN
	DECLARE @s varchar(8000)
    set @s = ';'
    select @s = @s +CONVERT(varchar, ClientGroup.GroupName)+';' from clientcom 
               left Join ClientGroup On ClientGroup.GroupID=clientcom.GroupID where clientcom.CuserID=@UserID
	if(@s=';')
	begin
	  set @s =NULL
	end
    RETURN @s
END
GO

