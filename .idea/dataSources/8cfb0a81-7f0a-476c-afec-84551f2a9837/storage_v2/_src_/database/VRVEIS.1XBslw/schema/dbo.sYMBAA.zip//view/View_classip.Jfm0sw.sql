
CREATE VIEW dbo.View_classip
AS
SELECT dbo.IPRange.RangeID, dbo.Class.ClassID, dbo.Class.ClassName, 
      dbo.IPRange.IPStart, dbo.IPRange.IPEnd, dbo.Class.UpID, dbo.Class.ClassCode, 
      dbo.Class.HostUrl1, dbo.Class.HostUrl2, dbo.Class.PreventType, 
      dbo.Class.ScanPreType, dbo.Class.Description1, dbo.Class.Description2, 
      dbo.Class.Description3, dbo.IPRange.ScanID, dbo.IPRange.IPMask, 
      dbo.IPRange.Reserved1, dbo.IPRange.Reserved2, dbo.IPRange.IsScan
FROM dbo.Class INNER JOIN
      dbo.IPRange ON dbo.Class.ClassID = dbo.IPRange.ClassID
GO

