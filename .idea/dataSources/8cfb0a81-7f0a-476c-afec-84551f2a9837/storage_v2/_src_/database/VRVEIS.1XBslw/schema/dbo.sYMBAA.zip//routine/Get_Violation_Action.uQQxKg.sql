CREATE  proc  [dbo].[Get_Violation_Action]
as
begin
declare  @ViolationTypeNm varchar(1000)  --违规类型数量
declare  @TmpViolationTypeNm varchar(1000)  --违规类型数量
declare  @ErrotTypeNm varchar(1000)  --异常类型数量
declare  @TmpErrotTypeNm varchar(1000)  --异常类型数量
declare  @StateTypeNm varchar(1000)   --一般行为数量
declare  @TmpStateTypeNm varchar(1000)   --一般行为数量
declare  @FidViolation varchar(1)   -- 违规类型fid
declare  @FidError varchar(1)   -- 异常类型fid
declare  @FidState varchar(1)   -- 一般行为fid
/*违规类型数量*/
set @FidViolation=1
set @FidError=2
set @FidState=3
declare  ActionCuror cursor  dynamic
for
Select isnull((KindID+','+Reserved1),'') From [Violations] Where    FID=@FidViolation
open   ActionCuror
set @ViolationTypeNm=''
set @TmpViolationTypeNm=''
fetch next  from  ActionCuror  into  @TmpViolationTypeNm
while(@@fetch_status=0)
begin   
    if(@TmpViolationTypeNm<>'')
     begin
     set @ViolationTypeNm=@ViolationTypeNm+@TmpViolationTypeNm+','
     end
	 set @ViolationTypeNm=replace(replace(@ViolationTypeNm,' ',''),',,',',')
	fetch next  from  ActionCuror  into  @TmpViolationTypeNm
end
set @ViolationTypeNm=replace(replace(@ViolationTypeNm,' ',''),',,',',')
if(left(@ViolationTypeNm,1)=',')
set @ViolationTypeNm=substring(@ViolationTypeNm,2,len(@ViolationTypeNm))
print @FidViolation
print  '违规类型数量str@ViolationTypeNm: '+@ViolationTypeNm
select @ViolationTypeNm=count(1) from  dbo.f_split(@ViolationTypeNm,',')
print  '违规类型数量num@ViolationTypeNm: '+@ViolationTypeNm
print ''
close ActionCuror 
deallocate ActionCuror
print '--异常类型数量'
declare  ActionCuror cursor  dynamic
for
Select isnull((KindID+','+Reserved1),'') From [Violations] Where    FID=@FidError
open   ActionCuror
set @ErrotTypeNm=''
set @TmpErrotTypeNm=''
fetch next  from  ActionCuror  into  @TmpErrotTypeNm
while(@@fetch_status=0)
begin
	if(@TmpErrotTypeNm<>'')
	begin
	set   @ErrotTypeNm=@ErrotTypeNm+@TmpErrotTypeNm+','
	end
	set @ErrotTypeNm=replace(replace(@ErrotTypeNm,' ',''),',,',',')
	fetch next  from  ActionCuror  into  @TmpErrotTypeNm
end
set @ErrotTypeNm=replace(replace(@ErrotTypeNm,' ',''),',,',',')
if(left(@ErrotTypeNm,1)=',')
set @ErrotTypeNm=substring(@ErrotTypeNm,2,len(@ErrotTypeNm))
print  '异常类型数量@ViolationTypeNm: '+@ErrotTypeNm
select @ErrotTypeNm=count(1) from  dbo.f_split(@ErrotTypeNm,',')
print  '异常类型数量@ViolationTypeNm: '+@ErrotTypeNm
print ''
close ActionCuror 
deallocate ActionCuror
/*一般行为数量*/
declare  ActionCuror cursor  dynamic
for
Select isnull((KindID+','+Reserved1),'') From [Violations] Where    FID=@FidState
open   ActionCuror
set @StateTypeNm=''
set @TmpStateTypeNm=''
fetch next  from  ActionCuror  into  @TmpStateTypeNm
while(@@fetch_status=0)
begin
     if(@TmpStateTypeNm<>'')
    begin
    set  @StateTypeNm=@StateTypeNm+@TmpStateTypeNm+','
    end
	set @StateTypeNm=replace(replace(@StateTypeNm,' ',''),',,',',')
	fetch next  from  ActionCuror  into  @TmpStateTypeNm
end
set @StateTypeNm=replace(replace(@StateTypeNm,' ',''),',,',',')
if(left(@StateTypeNm,1)=',')
set @StateTypeNm=substring(@StateTypeNm,2,len(@StateTypeNm))
print  '一般行为数量@StateTypeNm: '+@StateTypeNm
select @StateTypeNm=count(1) from  dbo.f_split(@StateTypeNm,',')
print  '一般行为数量@StateTypeNm: '+@StateTypeNm
print ''
close ActionCuror 
deallocate ActionCuror
print '--------------统计数量----------------------'
declare  @ViolationTypeAduit varchar(1000)  --违规类型
declare  @TmpViolationTypeAduit varchar(1000)  --违规类型
declare  @ViolationTypeError varchar(1000)  --违规类型
declare  @TmpViolationTypeError varchar(1000)  --违规类型
/*违规类型数量*/
set @ViolationTypeAduit=''
set @TmpViolationTypeAduit=''
set @ViolationTypeError=''
set @TmpViolationTypeError=''
declare  ActionCuror cursor  dynamic
for
Select isnull(KindID,''),isnull(Reserved1,'') From [Violations] Where    FID=@FidViolation
open   ActionCuror
fetch next  from  ActionCuror  into  @TmpViolationTypeAduit,@TmpViolationTypeError
while(@@fetch_status=0)
begin
    if(@TmpViolationTypeAduit<>'')
    begin
    print  'auditTest'
    print @TmpViolationTypeAduit
    print  'auditTestend'
    set @ViolationTypeAduit=@ViolationTypeAduit+@TmpViolationTypeAduit+','
    end
    if(@TmpViolationTypeError<>'')
    begin
    set @ViolationTypeError=@ViolationTypeError+@TmpViolationTypeError+','
    end
    set @ViolationTypeAduit=replace(replace(@ViolationTypeAduit,' ',''),',,',',')
	set @ViolationTypeError=replace(replace(@ViolationTypeError,' ',''),',,',',')
	fetch next  from  ActionCuror  into  @TmpViolationTypeAduit,@TmpViolationTypeError
end
set @ViolationTypeAduit=replace(replace(@ViolationTypeAduit,' ',''),',,',',')
set @ViolationTypeError=replace(replace(@ViolationTypeError,' ',''),',,',',')
print  '违规Aduit类型@ViolationTypeAduit: '+@ViolationTypeAduit
print  '违规error类型@ViolationTypeError: '+@ViolationTypeError
/*select * from  dbo.f_split(@ViolationTypeAduit,',') */
/*select * from  dbo.f_split(@ViolationTypeError,',') where a<>'' */
print ''
close ActionCuror 
deallocate ActionCuror
/*异常类型数量*/
declare  @ErrotTypeAduit varchar(1000)  --异常类型
declare  @TmpErrotTypeAduit varchar(1000)  --异常类型
declare  @ErrotTypeError varchar(1000)  --异常类型
declare  @TmpErrotTypeError varchar(1000)  --异常类型
set @ErrotTypeAduit=''
set @TmpErrotTypeAduit=''
set @ErrotTypeError=''
set @TmpErrotTypeError=''
declare  ActionCuror cursor  dynamic
for
Select isnull(KindID,''),isnull(Reserved1,'') From [Violations] Where    FID=@FidError
open   ActionCuror
fetch next  from  ActionCuror  into  @TmpErrotTypeAduit,@TmpErrotTypeError
while(@@fetch_status=0)
begin 
	if(@TmpErrotTypeAduit<>'')
    begin
    set @ErrotTypeAduit=@ErrotTypeAduit+@TmpErrotTypeAduit+','
	end
    if(@TmpErrotTypeError<>'')
    begin
    set @ErrotTypeError=@ErrotTypeError+@TmpErrotTypeError+','
	end
	set @ErrotTypeAduit=replace(replace(@ErrotTypeAduit,' ',''),',,',',')
	set @ErrotTypeError=replace(replace(@ErrotTypeError,' ',''),',,',',')
	fetch next  from  ActionCuror  into  @TmpErrotTypeAduit,@TmpErrotTypeError
end
set @ErrotTypeAduit=replace(replace(@ErrotTypeAduit,' ',''),',,',',')
set @ErrotTypeError=replace(replace(@ErrotTypeError,' ',''),',,',',')
print  '异常类型@ErrotTypeAduit: '+@ErrotTypeAduit
print  '异常类型@@ErrotTypeError: '+@ErrotTypeError
/*select * from  dbo.f_split(@ErrotTypeAduit,',') */
/*select * from  dbo.f_split(@ErrotTypeError,',') */
print ''
close ActionCuror 
deallocate ActionCuror
/*一般行为数量*/
declare  @StateTypeAduit varchar(1000)  --一般行为类型
declare  @TmpStateTypeAduit varchar(1000)  --一般行为类型
declare  @StateTypeError varchar(1000)  --一般行为类型
declare  @TmpStateTypeError varchar(1000)  --一般行为类型
set @StateTypeAduit=''
set @TmpStateTypeAduit=''
set @StateTypeError=''
set @TmpStateTypeError=''
declare  ActionCuror cursor  dynamic
for
Select isnull(KindID,''),isnull(Reserved1,'') From [Violations] Where    FID=@FidState
open   ActionCuror
fetch next  from  ActionCuror  into  @TmpStateTypeAduit,@TmpStateTypeError
while(@@fetch_status=0)
begin
	 if(@TmpStateTypeAduit<>'')
    begin
    set @StateTypeAduit=@StateTypeAduit+@TmpStateTypeAduit+','
	 end
    if(@TmpStateTypeError<>'')
    begin
    set @StateTypeError=@StateTypeError+@TmpStateTypeError+','
	end
	set @StateTypeAduit=replace(replace(@StateTypeAduit,' ',''),',,',',')
	set @StateTypeError=replace(replace(@StateTypeError,' ',''),',,',',')
	fetch next  from  ActionCuror  into  @TmpStateTypeAduit,@TmpStateTypeError
end
set @StateTypeAduit=replace(replace(@StateTypeAduit,' ',''),',,',',')
set @StateTypeError=replace(replace(@StateTypeError,' ',''),',,',',')
print  '一般类型@StateTypeAduit: '+@StateTypeAduit
print  '一般类型@StateTypeAduit: '+@StateTypeError   
/*select * from  dbo.f_split(@StateTypeAduit,',') */
/*select * from  dbo.f_split(@StateTypeError,',') */
print ''
close ActionCuror 
deallocate ActionCuror
print '----------------开启统计--------------------'
declare  @ViolationTypeAuditTotal nvarchar(64)  --违规类型数量
declare  @ViolationTypeErrorTotal nvarchar(64)  --违规类型数量
declare  @ErrotTypeAuditTotal varchar(64)  --异常类型数量
declare  @ErrotTypeErrorTotal varchar(64)  --异常类型数量
declare  @StateTypeAuditTotal varchar(64)   --一般行为数量
declare  @StateTypeErrorTotal varchar(64)   --一般行为数量
declare  @ViolationTypeScript nvarchar(4000)   --违规类型数量
declare  @ViolationTypeScriptTmp nvarchar(4000)   --违规类型数量
declare  @ErrotTypeScript nvarchar(4000)   --异常类型数量
declare  @ErrotTypeScriptTmp nvarchar(4000)   --异常类型数量
declare  @StateTypeScript nvarchar(4000)   --一般行为数量
declare  @StateTypeScriptTmp nvarchar(4000)   --一般行为数量
declare  @AuditTypeNum varchar(50)   --标识
declare  @AuditTable varchar(200)   --数据表
set @ViolationTypeScript=''
set @ViolationTypeScriptTmp=''
set @ErrotTypeScript=''
set @ErrotTypeScriptTmp=''
set @StateTypeScript=''
set @StateTypeScriptTmp=''
print  'test'
print  @ViolationTypeAduit
print  'test end'
select  @ViolationTypeErrorTotal=count(1) from errormessage  where errortype in(select * from  dbo.f_split(@ViolationTypeError,',') where a<>'')
select  @ErrotTypeErrorTotal=count(1) from errormessage  where errortype in(select * from  dbo.f_split(@ErrotTypeError,',') where a<>'')
select  @StateTypeErrorTotal=count(1) from errormessage  where errortype in(select * from  dbo.f_split(@StateTypeError,',') where a<>'')
/*select  AuditTypeNum,AuditTable  from audittypelist  where AuditTypeNum in()*/
declare  ActionCuror cursor  dynamic
for
select  AuditTypeNum,AuditTable  from audittypelist  where AuditValid=1 And AuditTypeNum in(select * from  dbo.f_split(@ViolationTypeAduit,','))
open   ActionCuror
fetch next  from  ActionCuror  into  @AuditTypeNum,@AuditTable
set @ViolationTypeScript='select @ViolationTypeAuditTotal=sum(A.Num) from  ('
set @ViolationTypeScript=@ViolationTypeScript+' select 0  as Num '
while(@@fetch_status=0)
begin
		set @ViolationTypeScriptTmp=@ViolationTypeScriptTmp+' union select count(1) as Num from '+@AuditTable+'  where extnum='+@AuditTypeNum
	fetch next  from  ActionCuror  into  @AuditTypeNum,@AuditTable
end
set @ViolationTypeScript=@ViolationTypeScript+@ViolationTypeScriptTmp+') as  A '
exec sp_executesql @ViolationTypeScript,N'@ViolationTypeAuditTotal int OUTPUT',@ViolationTypeAuditTotal OUTPUT
print  '违规类型数量纪录总数:'+@ViolationTypeAuditTotal
print ''
close ActionCuror 
deallocate ActionCuror
/*select  AuditTypeNum,AuditTable  from audittypelist  where AuditTypeNum in()*/
declare  ActionCuror cursor  dynamic
for
select  AuditTypeNum,AuditTable  from audittypelist  where AuditValid=1 And AuditTypeNum in(select * from  dbo.f_split(@ErrotTypeAduit,','))
open   ActionCuror
fetch next  from  ActionCuror  into  @AuditTypeNum,@AuditTable
set @ErrotTypeScript='select @ErrotTypeAuditTotal=sum(A.Num) from  ('
set @ErrotTypeScript=@ErrotTypeScript+' select 0  as Num '
while(@@fetch_status=0)
begin
		set @ErrotTypeScriptTmp=@ErrotTypeScriptTmp+' union select count(1) as Num from '+@AuditTable+'  where extnum='+@AuditTypeNum
	fetch next  from  ActionCuror  into  @AuditTypeNum,@AuditTable
end
set @ErrotTypeScript=@ErrotTypeScript+@ErrotTypeScriptTmp+') as  A '
exec sp_executesql @ErrotTypeScript,N'@ErrotTypeAuditTotal int OUTPUT',@ErrotTypeAuditTotal OUTPUT
print  '异常类型数量纪录总数:'+@ErrotTypeAuditTotal
print ''
close ActionCuror 
deallocate ActionCuror
/*select  AuditTypeNum,AuditTable  from audittypelist  where AuditTypeNum in()*/
declare  ActionCuror cursor  dynamic
for
select  AuditTypeNum,AuditTable  from audittypelist  where AuditValid=1 And AuditTypeNum in(select * from  dbo.f_split(@StateTypeAduit,','))
open   ActionCuror
fetch next  from  ActionCuror  into  @AuditTypeNum,@AuditTable
set @StateTypeScript='select @StateTypeAuditTotal=sum(A.Num) from  ('
set @StateTypeScript=@StateTypeScript+' select 0  as Num '
while(@@fetch_status=0)
begin
		set @StateTypeScriptTmp=@StateTypeScriptTmp+' union select count(1) as Num from '+@AuditTable+'  where extnum='+@AuditTypeNum
	fetch next  from  ActionCuror  into  @AuditTypeNum,@AuditTable
end
set @StateTypeScript=@StateTypeScript+@StateTypeScriptTmp+') as  A '
exec sp_executesql @StateTypeScript,N'@StateTypeAuditTotal int OUTPUT',@StateTypeAuditTotal OUTPUT
print  '一般行为数量纪录总数:'+@StateTypeAuditTotal
print ''
close ActionCuror 
deallocate ActionCuror
select *  from (
select  '违规行为' as [Type],@ViolationTypeNm as TypeNum ,(cast(@ViolationTypeAuditTotal as int)+cast(@ViolationTypeErrorTotal as int)) as	StatisticsNum
union
select  '异常行为' as TypeAction ,@ErrotTypeNm as TypeNum ,(cast(@ErrotTypeAuditTotal as int)+cast(@ErrotTypeErrorTotal as int)) as	StatisticsNum
union
select  '一般行为' as TypeAction ,@StateTypeNm as TypeNum ,(cast(@StateTypeAuditTotal as int)+cast(@StateTypeErrorTotal as int)) as	StatisticsNum
 ) as  AA order by  AA.TypeNum DESC
delete from TempCountAll where 1=1
insert into TempCountAll   select *  from (
select  '违规行为' as [Type],@ViolationTypeNm as TypeNum ,(cast(@ViolationTypeAuditTotal as int)+cast(@ViolationTypeErrorTotal as int)) as	StatisticsNum
union
select  '异常行为' as TypeAction ,@ErrotTypeNm as TypeNum ,(cast(@ErrotTypeAuditTotal as int)+cast(@ErrotTypeErrorTotal as int)) as	StatisticsNum
union
select  '一般行为' as TypeAction ,@StateTypeNm as TypeNum ,(cast(@StateTypeAuditTotal as int)+cast(@StateTypeErrorTotal as int)) as	StatisticsNum
 ) as  AA order by  AA.TypeNum DESC
end
GO

