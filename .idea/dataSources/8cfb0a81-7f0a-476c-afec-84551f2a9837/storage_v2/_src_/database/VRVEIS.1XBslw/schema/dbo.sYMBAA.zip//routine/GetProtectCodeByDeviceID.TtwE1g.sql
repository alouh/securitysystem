CREATE FUNCTION GetProtectCodeByDeviceID
(
	@DeviceID numeric(18,0),
	@OrganCode varchar(500)
)
RETURNS varchar(600)
AS
BEGIN
	DECLARE @ProtectCode varchar(600)
	select top 1 @ProtectCode=protectCode from  ProtectDevice where deviceid=@DeviceID order by id desc
	if(ISNULL(@ProtectCode,'') ='')
	begin
	   SET @ProtectCode=NULL
	end
	else
	begin
	   SET @ProtectCode= ISNULL(@OrganCode,'') + @ProtectCode
	end
	RETURN @ProtectCode
END
GO

