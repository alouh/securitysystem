
CREATE VIEW dbo.View_regRun
AS
SELECT dbo.MapRegion.RegID, dbo.MapRegion.OrganCode, dbo.MapRegion.OrganName, 
      dbo.MapRegion.RegName, dbo.MapRegion.IPAddress, dbo.MapRegion.RunStatus, 
      dbo.MapRegion.TotleCount, dbo.MapRegion.RegisterCount, 
      dbo.MapRegion.OnLineCount, dbo.MapIPRange.RangeID, dbo.MapIPRange.StartIP, 
      dbo.MapIPRange.EndIP, dbo.MapIPRange.Flag, dbo.MapRegion.Count1, 
      dbo.MapRegion.Count2, dbo.MapRegion.Count3, dbo.MapRegion.Count4, 
      dbo.MapRegion.Count5, dbo.MapRegion.Count6, dbo.MapRegion.Count7, 
      dbo.MapRegion.Count8, dbo.MapRegion.PosY, dbo.MapRegion.PosX, 
      dbo.MapRegion.DeviceName, dbo.MapRegion.MapID, dbo.MapRegion.NextMapID, 
      dbo.MapIPRange.ScanID
FROM dbo.MapIPRange INNER JOIN
      dbo.MapRegion ON dbo.MapIPRange.RegID = dbo.MapRegion.RegID
GO

